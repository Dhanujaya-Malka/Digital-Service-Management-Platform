import { xuiService } from './xui';

async function run() {
  await xuiService.login();
  const uuid = 'c7b5b542-a89e-4e4b-97e3-0d513812abcd';
  const email = 'test_client_01@v2nexus.net';
  
  const tests = [
    { method: 'POST', path: `/panel/api/inbounds/1/delClient/${uuid}` },
    { method: 'POST', path: `/panel/api/inbounds/delClient/${uuid}` },
    { method: 'POST', path: `/panel/api/inbounds/1/delClient/${email}` },
    { method: 'POST', path: `/panel/api/clients/${uuid}/delete` },
    { method: 'POST', path: `/panel/api/clients/${email}/delete` },
    { method: 'DELETE', path: `/panel/api/clients/${uuid}` },
    { method: 'DELETE', path: `/panel/api/clients/${email}` },
    { method: 'POST', path: `/panel/api/clients/delete`, body: JSON.stringify({ email }) },
  ];

  for (const t of tests) {
    const res = await (xuiService as any).makeRequest(
      t.path,
      t.method as any,
      {
        Cookie: (xuiService as any).sessionCookie,
        'X-CSRF-Token': (xuiService as any).csrfToken,
        'X-Requested-With': 'XMLHttpRequest',
        'Content-Type': 'application/json',
      },
      t.body
    );
    console.log(`${t.method} ${t.path} => ${res.statusCode}: ${res.body.substring(0, 80)}`);
    if (res.body.includes('"success":true')) {
      console.log('🎉 FOUND WORKING DELETE ENDPOINT:', t.method, t.path);
      break;
    }
  }
}

run();
