import { xuiService } from './xui';

async function run() {
  const loginOk = await xuiService.login();
  console.log('Login success:', loginOk);

  const payload = JSON.stringify({
    client: {
      id: 'c7b5b542-a89e-4e4b-97e3-0d513812abcd',
      email: 'test_client_01@v2nexus.net',
      totalGB: 10737418240,
      expiryTime: Date.now() + 30 * 24 * 3600 * 1000,
      tgId: 0,
      limitIp: 2,
      limitHwid: 0,
      enable: true,
    },
    inboundIds: [1],
  });

  const res = await (xuiService as any).makeRequest(
    '/panel/api/clients/add',
    'POST',
    {
      Cookie: (xuiService as any).sessionCookie,
      'Content-Type': 'application/json',
      'X-Requested-With': 'XMLHttpRequest',
      'X-CSRF-Token': (xuiService as any).csrfToken,
    },
    payload
  );

  console.log('clients/add status:', res.statusCode);
  console.log('clients/add response:', res.body);
}

run();
