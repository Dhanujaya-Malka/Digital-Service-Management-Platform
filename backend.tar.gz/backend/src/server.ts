
import express from "express";
import cors from "cors";
import { pool } from "./db";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import { requireAuth, type AuthRequest } from "./auth.js";
import { generateOtp, sendOtpEmail } from "./email.js";
import crypto from "crypto";
import { xuiService } from "./xui";






const app = express();

app.use(cors({
  origin: true,
  credentials: true,
}));

app.use(express.json());

// ================================
// 1. Backend health check
// ================================
app.get("/", (_req, res) => {
  res.json({
    message: "SecureVPN Backend is running!",
  });
});

// ================================
// 2. Database health check
// ================================
app.get("/api/health/db", async (_req, res) => {
  try {
    const result = await pool.query(
      "SELECT NOW() AS current_time"
    );

    res.json({
      status: "connected",
      databaseTime: result.rows[0].current_time,
    });
  } catch (error) {
    console.error("Database connection failed:", error);

    res.status(500).json({
      status: "disconnected",
      message: "Database connection failed",
    });
  }
});

// ================================
// Packages API (PostgreSQL Connected)
// ================================

// 1. Get all packages
app.get("/api/packages", async (req, res) => {
  try {
    const includeAll = req.query.all === "true";
    const query = includeAll
      ? "SELECT * FROM packages ORDER BY id ASC"
      : "SELECT * FROM packages WHERE is_active = true ORDER BY id ASC";

    const result = await pool.query(query);

    const formatted = result.rows.map((row) => ({
      id: row.slug || row.id.toString(),
      db_id: row.id,
      name: row.name,
      price: Number(row.price_lkr),
      duration: Number(row.duration_days) || 30,
      trafficLimit: Number(row.traffic_limit_gb) || 0,
      deviceLimit: row.device_limit
        ? `${row.device_limit} Device${row.device_limit > 1 ? "s" : ""}`
        : "1 Device",
      features: Array.isArray(row.features)
        ? row.features
        : typeof row.features === "string"
        ? JSON.parse(row.features)
        : [],
      popular: Boolean(row.popular),
      availableSlots: Number(row.available_slots) || 100,
      category: (row.category || "basic").toLowerCase(),
      serverLocation: row.server_location || "SG SERVER",
      validity: row.validity || "1 Month",
      p2pTorrent: row.p2p_torrent || "Restricted",
      speedLimit: row.speed_limit || "No Speed Limit",
      badge: row.badge || (row.popular ? "POPULAR" : "ACTIVE"),
      sni: row.sni || "aka.ms",
      isActive: Boolean(row.is_active),
    }));

    res.json(formatted);
  } catch (error) {
    console.error("Failed to fetch packages:", error);
    res.status(500).json({ message: "Failed to fetch packages from database." });
  }
});

// 2. Get single package
app.get("/api/packages/:id", async (req, res) => {
  try {
    const identifier = req.params.id;
    const result = await pool.query(
      "SELECT * FROM packages WHERE slug = $1 OR id::text = $1 LIMIT 1",
      [identifier]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ message: "Package not found." });
    }

    const row = result.rows[0];
    res.json({
      id: row.slug || row.id.toString(),
      db_id: row.id,
      name: row.name,
      price: Number(row.price_lkr),
      duration: Number(row.duration_days) || 30,
      trafficLimit: Number(row.traffic_limit_gb) || 0,
      deviceLimit: row.device_limit
        ? `${row.device_limit} Device${row.device_limit > 1 ? "s" : ""}`
        : "1 Device",
      features: Array.isArray(row.features)
        ? row.features
        : typeof row.features === "string"
        ? JSON.parse(row.features)
        : [],
      popular: Boolean(row.popular),
      availableSlots: Number(row.available_slots) || 100,
      category: (row.category || "basic").toLowerCase(),
      serverLocation: row.server_location || "SG SERVER",
      validity: row.validity || "1 Month",
      p2pTorrent: row.p2p_torrent || "Restricted",
      speedLimit: row.speed_limit || "No Speed Limit",
      badge: row.badge || (row.popular ? "POPULAR" : "ACTIVE"),
      sni: row.sni || "aka.ms",
      isActive: Boolean(row.is_active),
    });
  } catch (error) {
    console.error("Failed to fetch package:", error);
    res.status(500).json({ message: "Failed to fetch package." });
  }
});

// 3. Create a new package (Admin)
app.post("/api/packages", async (req, res) => {
  try {
    const {
      id,
      name,
      price,
      duration,
      trafficLimit,
      deviceLimit,
      features,
      popular,
      availableSlots,
      category,
      serverLocation,
      validity,
      p2pTorrent,
      speedLimit,
      badge,
    } = req.body;

    if (!name || price === undefined) {
      return res.status(400).json({ message: "Package name and price are required." });
    }

    const slug = id || name.toLowerCase().replace(/[^a-z0-9]/g, "-");
    const numericDeviceLimit =
      typeof deviceLimit === "number"
        ? deviceLimit
        : parseInt(String(deviceLimit || "").replace(/\D/g, "")) || 1;

    const insertQuery = `
      INSERT INTO packages (
        slug, name, category, price_lkr, duration_days, traffic_limit_gb, device_limit,
        features, popular, available_slots, server_location, validity, p2p_torrent, speed_limit, badge, sni, is_active
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, true)
      RETURNING *;
    `;

    const result = await pool.query(insertQuery, [
      slug,
      name,
      (category || "BASIC").toUpperCase(),
      price,
      duration || 30,
      trafficLimit || 0,
      numericDeviceLimit,
      JSON.stringify(features || []),
      Boolean(popular),
      availableSlots || 100,
      serverLocation || "SG SERVER",
      validity || "1 Month",
      p2pTorrent || "Restricted",
      speedLimit || "No Speed Limit",
      badge || (popular ? "POPULAR" : "ACTIVE"),
      req.body.sni && typeof req.body.sni === "string" ? req.body.sni.trim() : "aka.ms",
    ]);

    const row = result.rows[0];
    res.status(201).json({
      id: row.slug || row.id.toString(),
      db_id: row.id,
      name: row.name,
      price: Number(row.price_lkr),
      duration: Number(row.duration_days),
      trafficLimit: Number(row.traffic_limit_gb),
      deviceLimit: `${row.device_limit} Device${row.device_limit > 1 ? "s" : ""}`,
      features: Array.isArray(row.features)
        ? row.features
        : typeof row.features === "string"
        ? JSON.parse(row.features)
        : [],
      popular: Boolean(row.popular),
      availableSlots: Number(row.available_slots),
      category: (row.category || "basic").toLowerCase(),
      serverLocation: row.server_location,
      validity: row.validity,
      p2pTorrent: row.p2p_torrent,
      speedLimit: row.speed_limit,
      badge: row.badge,
      sni: row.sni || "aka.ms",
      isActive: Boolean(row.is_active),
    });
  } catch (error) {
    console.error("Failed to create package:", error);
    res.status(500).json({ message: "Failed to create package in database." });
  }
});

// 4. Update an existing package (Admin)
app.put("/api/packages/:id", async (req, res) => {
  try {
    const identifier = req.params.id;
    const {
      name,
      price,
      duration,
      trafficLimit,
      deviceLimit,
      features,
      popular,
      availableSlots,
      category,
      serverLocation,
      validity,
      p2pTorrent,
      speedLimit,
      badge,
      isActive,
    } = req.body;

    const numericDeviceLimit =
      deviceLimit !== undefined
        ? typeof deviceLimit === "number"
          ? deviceLimit
          : parseInt(String(deviceLimit || "").replace(/\D/g, "")) || 1
        : null;

    const updateQuery = `
      UPDATE packages SET
        name = COALESCE($1, name),
        price_lkr = COALESCE($2, price_lkr),
        duration_days = COALESCE($3, duration_days),
        traffic_limit_gb = COALESCE($4, traffic_limit_gb),
        device_limit = COALESCE($5, device_limit),
        features = COALESCE($6, features),
        popular = COALESCE($7, popular),
        available_slots = COALESCE($8, available_slots),
        category = COALESCE($9, category),
        server_location = COALESCE($10, server_location),
        validity = COALESCE($11, validity),
        p2p_torrent = COALESCE($12, p2p_torrent),
        speed_limit = COALESCE($13, speed_limit),
        badge = COALESCE($14, badge),
        sni = COALESCE($15, sni),
        is_active = COALESCE($16, is_active)
      WHERE slug = $17 OR id::text = $17
      RETURNING *;
    `;

    const result = await pool.query(updateQuery, [
      name || null,
      price !== undefined ? price : null,
      duration !== undefined ? duration : null,
      trafficLimit !== undefined ? trafficLimit : null,
      numericDeviceLimit,
      features ? JSON.stringify(features) : null,
      popular !== undefined ? Boolean(popular) : null,
      availableSlots !== undefined ? availableSlots : null,
      category ? category.toUpperCase() : null,
      serverLocation || null,
      validity || null,
      p2pTorrent || null,
      speedLimit || null,
      badge || null,
      req.body.sni !== undefined ? (req.body.sni ? String(req.body.sni).trim() : "aka.ms") : null,
      isActive !== undefined ? Boolean(isActive) : null,
      identifier,
    ]);

    if (result.rows.length === 0) {
      return res.status(404).json({ message: "Package not found." });
    }

    const row = result.rows[0];
    res.json({
      id: row.slug || row.id.toString(),
      db_id: row.id,
      name: row.name,
      price: Number(row.price_lkr),
      duration: Number(row.duration_days),
      trafficLimit: Number(row.traffic_limit_gb),
      deviceLimit: `${row.device_limit} Device${row.device_limit > 1 ? "s" : ""}`,
      features: Array.isArray(row.features)
        ? row.features
        : typeof row.features === "string"
        ? JSON.parse(row.features)
        : [],
      popular: Boolean(row.popular),
      availableSlots: Number(row.available_slots),
      category: (row.category || "basic").toLowerCase(),
      serverLocation: row.server_location,
      validity: row.validity,
      p2pTorrent: row.p2p_torrent,
      speedLimit: row.speed_limit,
      badge: row.badge,
      sni: row.sni || "aka.ms",
      isActive: Boolean(row.is_active),
    });
  } catch (error) {
    console.error("Failed to update package:", error);
    res.status(500).json({ message: "Failed to update package in database." });
  }
});

// 5. Delete / Deactivate a package (Admin)
app.delete("/api/packages/:id", async (req, res) => {
  try {
    const identifier = req.params.id;
    const result = await pool.query(
      "UPDATE packages SET is_active = false WHERE slug = $1 OR id::text = $1 RETURNING id, name",
      [identifier]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ message: "Package not found." });
    }

    res.json({
      message: "Package deactivated successfully in database.",
      id: identifier,
    });
  } catch (error) {
    console.error("Failed to delete package:", error);
    res.status(500).json({ message: "Failed to delete package." });
  }
});

// ==========================================
// Network Packages API (PostgreSQL Connected with Dynamic SNI)
// ==========================================

// 1. Get all network packages
app.get("/api/network-packages", async (req, res) => {
  try {
    const result = await pool.query("SELECT * FROM network_packages ORDER BY id ASC");
    const formatted = result.rows.map((row) => ({
      id: row.id,
      name: row.name,
      isp: row.isp,
      ispName: row.isp_name,
      status: row.status || "active",
      serverLocation: row.server_location || "SG SERVER",
      validity: row.validity || "1 Month",
      p2pTorrent: row.p2p_torrent || "Restricted",
      speedLimit: row.speed_limit || "No Speed Limit",
      popular: Boolean(row.popular),
      latency: row.latency || "30ms - 40ms",
      description: row.description || "",
      sni: row.sni || "aka.ms",
      features: Array.isArray(row.features)
        ? row.features
        : typeof row.features === "string"
        ? JSON.parse(row.features)
        : [],
      supportedProtocols: Array.isArray(row.supported_protocols)
        ? row.supported_protocols
        : typeof row.supported_protocols === "string"
        ? JSON.parse(row.supported_protocols)
        : ["VLESS + Reality", "WebSocket TLS"],
    }));
    res.json(formatted);
  } catch (error) {
    console.error("Failed to fetch network packages:", error);
    res.status(500).json({ message: "Failed to fetch network packages from database." });
  }
});

// 2. Create new network package
app.post("/api/network-packages", async (req, res) => {
  try {
    const {
      id,
      name,
      isp,
      ispName,
      status,
      serverLocation,
      validity,
      p2pTorrent,
      speedLimit,
      popular,
      features,
      supportedProtocols,
      latency,
      description,
      sni,
    } = req.body;

    if (!name || !isp) {
      return res.status(400).json({ message: "Package name and ISP are required." });
    }

    const packageId = id || `${isp}-${Date.now().toString(36)}`;
    const insertQuery = `
      INSERT INTO network_packages (
        id, name, isp, isp_name, status, server_location, validity, p2p_torrent,
        speed_limit, popular, features, supported_protocols, latency, description, sni, updated_at
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, NOW())
      ON CONFLICT (id) DO UPDATE SET
        name = EXCLUDED.name,
        isp = EXCLUDED.isp,
        isp_name = EXCLUDED.isp_name,
        status = EXCLUDED.status,
        server_location = EXCLUDED.server_location,
        validity = EXCLUDED.validity,
        p2p_torrent = EXCLUDED.p2p_torrent,
        speed_limit = EXCLUDED.speed_limit,
        popular = EXCLUDED.popular,
        features = EXCLUDED.features,
        supported_protocols = EXCLUDED.supported_protocols,
        latency = EXCLUDED.latency,
        description = EXCLUDED.description,
        sni = EXCLUDED.sni,
        updated_at = NOW()
      RETURNING *;
    `;

    const result = await pool.query(insertQuery, [
      packageId,
      name,
      isp,
      ispName || isp.toUpperCase(),
      status || "active",
      serverLocation || "SG SERVER",
      validity || "1 Month",
      p2pTorrent || "Restricted",
      speedLimit || "No Speed Limit",
      Boolean(popular),
      JSON.stringify(features || []),
      JSON.stringify(supportedProtocols || ["VLESS + Reality", "WebSocket TLS"]),
      latency || "30ms - 40ms",
      description || "",
      sni ? sni.trim() : "aka.ms",
    ]);

    const row = result.rows[0];
    res.status(201).json({
      id: row.id,
      name: row.name,
      isp: row.isp,
      ispName: row.isp_name,
      status: row.status,
      serverLocation: row.server_location,
      validity: row.validity,
      p2pTorrent: row.p2p_torrent,
      speedLimit: row.speed_limit,
      popular: Boolean(row.popular),
      latency: row.latency,
      description: row.description,
      sni: row.sni,
      features: Array.isArray(row.features) ? row.features : JSON.parse(row.features || "[]"),
      supportedProtocols: Array.isArray(row.supported_protocols) ? row.supported_protocols : JSON.parse(row.supported_protocols || "[]"),
    });
  } catch (error) {
    console.error("Failed to save network package:", error);
    res.status(500).json({ message: "Failed to save network package to database." });
  }
});

// 3. Update network package (including SNI)
app.put("/api/network-packages/:id", async (req, res) => {
  try {
    const pkgId = req.params.id;
    const {
      name,
      isp,
      ispName,
      status,
      serverLocation,
      validity,
      p2pTorrent,
      speedLimit,
      popular,
      features,
      supportedProtocols,
      latency,
      description,
      sni,
    } = req.body;

    const updateQuery = `
      UPDATE network_packages SET
        name = COALESCE($1, name),
        isp = COALESCE($2, isp),
        isp_name = COALESCE($3, isp_name),
        status = COALESCE($4, status),
        server_location = COALESCE($5, server_location),
        validity = COALESCE($6, validity),
        p2p_torrent = COALESCE($7, p2p_torrent),
        speed_limit = COALESCE($8, speed_limit),
        popular = COALESCE($9, popular),
        features = COALESCE($10, features),
        supported_protocols = COALESCE($11, supported_protocols),
        latency = COALESCE($12, latency),
        description = COALESCE($13, description),
        sni = COALESCE($14, sni),
        updated_at = NOW()
      WHERE id = $15
      RETURNING *;
    `;

    const result = await pool.query(updateQuery, [
      name || null,
      isp || null,
      ispName || null,
      status || null,
      serverLocation || null,
      validity || null,
      p2pTorrent || null,
      speedLimit || null,
      popular !== undefined ? Boolean(popular) : null,
      features ? JSON.stringify(features) : null,
      supportedProtocols ? JSON.stringify(supportedProtocols) : null,
      latency || null,
      description || null,
      sni !== undefined ? (sni ? String(sni).trim() : "aka.ms") : null,
      pkgId,
    ]);

    if (result.rows.length === 0) {
      return res.status(404).json({ message: "Network package not found." });
    }

    const row = result.rows[0];
    res.json({
      id: row.id,
      name: row.name,
      isp: row.isp,
      ispName: row.isp_name,
      status: row.status,
      serverLocation: row.server_location,
      validity: row.validity,
      p2pTorrent: row.p2p_torrent,
      speedLimit: row.speed_limit,
      popular: Boolean(row.popular),
      latency: row.latency,
      description: row.description,
      sni: row.sni,
      features: Array.isArray(row.features) ? row.features : JSON.parse(row.features || "[]"),
      supportedProtocols: Array.isArray(row.supported_protocols) ? row.supported_protocols : JSON.parse(row.supported_protocols || "[]"),
    });
  } catch (error) {
    console.error("Failed to update network package:", error);
    res.status(500).json({ message: "Failed to update network package." });
  }
});

// 4. Delete network package
app.delete("/api/network-packages/:id", async (req, res) => {
  try {
    const pkgId = req.params.id;
    const result = await pool.query("DELETE FROM network_packages WHERE id = $1 RETURNING id, name", [pkgId]);
    if (result.rows.length === 0) {
      return res.status(404).json({ message: "Network package not found." });
    }
    res.json({ message: "Network package deleted successfully.", id: pkgId });
  } catch (error) {
    console.error("Failed to delete network package:", error);
    res.status(500).json({ message: "Failed to delete network package." });
  }
});

// ==========================================
// 6. Capacity Settings & Monthly Quota Reset
// ==========================================

// Initialize system_settings table if not exists
pool.query(`
  CREATE TABLE IF NOT EXISTS system_settings (
    key VARCHAR(100) PRIMARY KEY,
    value TEXT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
  );
`).catch((err) => console.error("Failed to create system_settings table:", err));

// Get Capacity and Monthly Reset Settings
app.get("/api/admin/capacity-settings", async (_req, res) => {
  try {
    const result = await pool.query(
      "SELECT key, value FROM system_settings WHERE key IN ('server_capacity_tb', 'last_quota_reset_date')"
    );
    const map: Record<string, string> = {};
    result.rows.forEach((r) => {
      map[r.key] = r.value;
    });

    const serverCapacityTb = parseFloat(map["server_capacity_tb"]) || 20;
    const lastQuotaResetDate = map["last_quota_reset_date"] || new Date().toISOString();

    res.json({
      serverCapacityTb,
      lastQuotaResetDate,
    });
  } catch (error) {
    console.error("Failed to get capacity settings:", error);
    res.status(500).json({ message: "Failed to load settings." });
  }
});

// Update Capacity Setting
app.post("/api/admin/capacity-settings", async (req, res) => {
  try {
    const { serverCapacityTb } = req.body;
    if (serverCapacityTb !== undefined) {
      await pool.query(`
        INSERT INTO system_settings (key, value, updated_at)
        VALUES ('server_capacity_tb', $1, NOW())
        ON CONFLICT (key) DO UPDATE SET value = $1, updated_at = NOW()
      `, [String(serverCapacityTb)]);
    }
    res.json({ message: "Capacity settings saved successfully.", serverCapacityTb });
  } catch (error) {
    console.error("Failed to save capacity settings:", error);
    res.status(500).json({ message: "Failed to save settings." });
  }
});

// Reset Monthly Quota and Restore Package Slots in Database
app.post("/api/admin/reset-monthly-quota", async (_req, res) => {
  try {
    // 1. Reset packages slots to default standard quotas in PostgreSQL
    const defaultSlots: Record<string, number> = {
      "basic-50gb": 150,
      "basic-100gb": 120,
      "basic-200gb": 95,
      "standard-250gb": 90,
      "standard-300gb": 85,
      "standard-400gb": 75,
      "premium-500gb": 65,
      "premium-750gb": 50,
      "premium-1000gb": 40,
      "ultimate-1500gb": 35,
      "ultimate-2000gb": 25,
    };

    for (const [slug, slots] of Object.entries(defaultSlots)) {
      await pool.query("UPDATE packages SET available_slots = $1 WHERE slug = $2", [slots, slug]);
    }

    // For any custom package without preset, reset to 100 slots
    await pool.query(
      `UPDATE packages SET available_slots = 100 WHERE slug NOT IN ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)`,
      [
        "basic-50gb", "basic-100gb", "basic-200gb", "standard-250gb", "standard-300gb",
        "standard-400gb", "premium-500gb", "premium-750gb", "premium-1000gb", "ultimate-1500gb", "ultimate-2000gb"
      ]
    );

    // 2. Record last_quota_reset_date in system_settings
    const nowIso = new Date().toISOString();
    await pool.query(`
      INSERT INTO system_settings (key, value, updated_at)
      VALUES ('last_quota_reset_date', $1, NOW())
      ON CONFLICT (key) DO UPDATE SET value = $1, updated_at = NOW()
    `, [nowIso]);

    res.json({
      message: "Monthly quota and package slots successfully reset in database.",
      lastQuotaResetDate: nowIso,
    });
  } catch (error) {
    console.error("Failed to reset monthly quota:", error);
    res.status(500).json({ message: "Failed to reset monthly quota in database." });
  }
});

// ==========================================
// 3X-UI Live VPN Provisioning & Management
// ==========================================

// 1. Check 3X-UI Connection Status
app.get("/api/vpn/status", async (_req, res) => {
  try {
    const isLogged = await xuiService.login();
    res.json({
      connected: isLogged,
      host: process.env.XUI_SERVER_HOST || "virtual-internet-access.duckdns.org",
      inboundId: process.env.XUI_INBOUND_ID || "1",
    });
  } catch (error: any) {
    res.status(500).json({ connected: false, error: error.message });
  }
});

// 2. Provision Real Client on 3X-UI VPS Inbound
app.post("/api/vpn/provision", async (req, res) => {
  try {
    const {
      orderId,
      email,
      customerName,
      packageName,
      networkName,
      sni,
      totalGB,
      expiryDays,
      uuid,
    } = req.body;

    const clientUuid = uuid || crypto.randomUUID();
    // Unique identifier for 3X-UI email (alphanumeric clean)
    const sanitizedEmail = (email || "user").replace(/[^a-zA-Z0-9]/g, "").slice(0, 15);
    const clientEmail = `${orderId || "vpn"}-${sanitizedEmail}`;
    const targetSni = (sni && String(sni).trim()) ? String(sni).trim() : "aka.ms";
    const remarkName = `${networkName || "SLT"}-${packageName || "Plan"}`.replace(/[^a-zA-Z0-9_-]/g, "-");

    const totalBytes = totalGB && Number(totalGB) > 0 ? Number(totalGB) * 1024 * 1024 * 1024 : 0;
    const expiryTimeMs = expiryDays && Number(expiryDays) > 0 ? Date.now() + Number(expiryDays) * 24 * 60 * 60 * 1000 : 0;

    const result = await xuiService.addClient(
      {
        uuid: clientUuid,
        email: clientEmail,
        totalBytes,
        expiryTimeMs,
        limitIp: 2,
        enable: true,
      },
      remarkName,
      targetSni
    );

    res.json({
      success: result.success,
      uuid: result.uuid,
      email: clientEmail,
      vlessUrl: result.vlessUrl,
      serverLocation: result.serverLocation,
      msg: result.msg,
    });
  } catch (error: any) {
    console.error("VPN provision error:", error);
    res.status(500).json({ success: false, message: error.message || "Failed to provision VPN client." });
  }
});

// 3. Revoke/Delete Client from 3X-UI VPS (Order Rejected/Cancelled)
app.post("/api/vpn/revoke", async (req, res) => {
  try {
    const { email, uuid } = req.body;
    const target = email || uuid;
    if (!target) {
      return res.status(400).json({ success: false, message: "Email or UUID is required." });
    }
    const success = await xuiService.deleteClient(String(target));
    res.json({
      success,
      message: success
        ? "VPN client successfully revoked and deleted from 3X-UI panel."
        : "Failed to revoke client or client not found in 3X-UI.",
    });
  } catch (error: any) {
    console.error("VPN revoke error:", error);
    res.status(500).json({ success: false, message: error.message || "Failed to revoke VPN client." });
  }
});

// 4. Get Client Traffic Statistics from 3X-UI
app.get("/api/vpn/traffic/:email", async (req, res) => {
  try {
    const email = req.params.email;
    const traffic = await xuiService.getClientTraffic(email);
    if (!traffic) {
      return res.status(404).json({ success: false, message: "Client traffic not available." });
    }
    res.json({ success: true, traffic });
  } catch (error: any) {
    console.error("Get traffic error:", error);
    res.status(500).json({ success: false, message: error.message || "Failed to fetch traffic." });
  }
});

// 5. Get All Clients Live Traffic Statistics from 3X-UI VPS
app.get("/api/vpn/traffic-all", async (_req, res) => {
  try {
    const stats = await xuiService.getAllClientStats();
    res.json({ success: true, stats });
  } catch (error: any) {
    console.error("Get all traffic error:", error);
    res.status(500).json({ success: false, message: error.message || "Failed to fetch all traffic." });
  }
});

// ================================
// 3. Create a new order
// ================================
app.post("/api/orders", async (req, res) => {
  const { user_id, package_id } = req.body;

  if (
    !Number.isSafeInteger(Number(user_id)) ||
    !Number.isSafeInteger(Number(package_id)) ||
    Number(user_id) <= 0 ||
    Number(package_id) <= 0 ||
    user_id === undefined ||
    user_id === null ||
    package_id === undefined ||
    package_id === null
  ) {
    return res.status(400).json({
      message: "Valid user_id and package_id are required.",
    });
  }

  let client;

  try {
    client = await pool.connect();

    await client.query("BEGIN");

    // Check whether the user exists
    const userResult = await client.query(
      `SELECT id
       FROM public.users
       WHERE id = $1`,
      [user_id]
    );

    if (userResult.rows.length === 0) {
      await client.query("ROLLBACK");

      return res.status(404).json({
        message: "User not found.",
      });
    }

    // Check whether the package exists and is active
    const packageResult = await client.query(
      `SELECT id, price_lkr
       FROM public.packages
       WHERE id = $1 AND is_active = TRUE`,
      [package_id]
    );

    if (packageResult.rows.length === 0) {
      await client.query("ROLLBACK");

      return res.status(404).json({
        message: "Active package not found.",
      });
    }

    // Use the package price stored in the database
    const amount = packageResult.rows[0].price_lkr;

    const orderResult = await client.query(
      `INSERT INTO public.orders
         (user_id, package_id, amount_lkr, status)
       VALUES ($1, $2, $3, 'PENDING')
       RETURNING id, user_id, package_id,
                 amount_lkr, status, created_at`,
      [user_id, package_id, amount]
    );

    await client.query("COMMIT");

    return res.status(201).json({
      message: "Order created successfully.",
      order: orderResult.rows[0],
    });
  } catch (error) {
    if (client) {
      try {
        await client.query("ROLLBACK");
      } catch (rollbackError) {
        console.error("Order rollback failed:", rollbackError);
      }
    }

    console.error("Order creation failed:", error);

    return res.status(500).json({
      message: "Could not create order.",
    });
  } finally {
    client?.release();
  }
});

// ================================
// 4. Submit a payment for an order
// ================================
app.post("/api/payments", async (req, res) => {
  const {
    order_id,
    payment_method,
    transaction_reference,
    payment_proof_url,
  } = req.body;

  const validMethods = [
    "BANK_TRANSFER",
    "CARD",
    "OTHER",
  ];

  if (
    !Number.isSafeInteger(Number(order_id)) ||
    Number(order_id) <= 0 ||
    order_id === undefined ||
    order_id === null ||
    !validMethods.includes(payment_method)
  ) {
    return res.status(400).json({
      message: "Valid order_id and payment_method are required.",
    });
  }

  if (
    transaction_reference !== undefined &&
    transaction_reference !== null &&
    typeof transaction_reference !== "string"
  ) {
    return res.status(400).json({
      message: "transaction_reference must be a string.",
    });
  }

  if (
    payment_proof_url !== undefined &&
    payment_proof_url !== null &&
    typeof payment_proof_url !== "string"
  ) {
    return res.status(400).json({
      message: "payment_proof_url must be a string.",
    });
  }

  let client;

  try {
    client = await pool.connect();

    await client.query("BEGIN");

    // Find and lock the order while submitting payment
    const orderResult = await client.query(
      `SELECT id, amount_lkr, status
       FROM public.orders
       WHERE id = $1
       FOR UPDATE`,
      [order_id]
    );

    if (orderResult.rows.length === 0) {
      await client.query("ROLLBACK");

      return res.status(404).json({
        message: "Order not found.",
      });
    }

    const order = orderResult.rows[0];

    if (order.status !== "PENDING") {
      await client.query("ROLLBACK");

      return res.status(400).json({
        message: "This order is not available for payment submission.",
      });
    }

    // Prevent duplicate pending payments
    const existingPayment = await client.query(
      `SELECT id
       FROM public.payments
       WHERE order_id = $1
         AND status = 'PENDING'`,
      [order_id]
    );

    if (existingPayment.rows.length > 0) {
      await client.query("ROLLBACK");

      return res.status(409).json({
        message: "A pending payment already exists for this order.",
      });
    }

    // Use the order amount from the database
    const paymentResult = await client.query(
      `INSERT INTO public.payments (
         order_id,
         amount_lkr,
         payment_method,
         transaction_reference,
         payment_proof_url,
         status
       )
       VALUES ($1, $2, $3, $4, $5, 'PENDING')
       RETURNING id, order_id, amount_lkr,
                 payment_method, transaction_reference,
                 status, created_at`,
      [
        order.id,
        order.amount_lkr,
        payment_method,
        transaction_reference?.trim() || null,
        payment_proof_url?.trim() || null,
      ]
    );

    await client.query("COMMIT");

    return res.status(201).json({
      message: "Payment submitted for review.",
      payment: paymentResult.rows[0],
    });
  } catch (error) {
    if (client) {
      try {
        await client.query("ROLLBACK");
      } catch (rollbackError) {
        console.error("Payment rollback failed:", rollbackError);
      }
    }

    console.error("Payment submission failed:", error);

    return res.status(500).json({
      message: "Could not submit payment.",
    });
  } finally {
    client?.release();
  }
});



 // ================================
 // 5. Approve a payment (development only)
 // ================================
app.post("/api/admin/payments/:id/approve", async (req, res) => {
  const paymentId = Number(req.params.id);

  if (!Number.isSafeInteger(paymentId) || paymentId <= 0) {
    return res.status(400).json({
      message: "Valid payment ID is required.",
    });
  }

  let client;

  try {
    client = await pool.connect();
    await client.query("BEGIN");

    const paymentResult = await client.query(
      `SELECT id, order_id, status
       FROM public.payments
       WHERE id = $1
       FOR UPDATE`,
      [paymentId]
    );

    if (paymentResult.rows.length === 0) {
      await client.query("ROLLBACK");
      return res.status(404).json({
        message: "Payment not found.",
      });
    }

    const payment = paymentResult.rows[0];

    if (payment.status !== "PENDING") {
      await client.query("ROLLBACK");
      return res.status(409).json({
        message: "Payment is not pending.",
      });
    }

    await client.query(
      `UPDATE public.payments
       SET status = 'APPROVED',
           reviewed_at = NOW()
       WHERE id = $1`,
      [paymentId]
    );

    await client.query(
      `UPDATE public.orders
       SET status = 'PAID',
           updated_at = NOW()
       WHERE id = $1`,
      [payment.order_id]
    );

    await client.query("COMMIT");

    return res.json({
      message: "Payment approved successfully.",
      payment_id: paymentId,
      order_id: payment.order_id,
      payment_status: "APPROVED",
      order_status: "PAID",
    });
  } catch (error) {
    if (client) {
      try {
        await client.query("ROLLBACK");
      } catch (rollbackError) {
        console.error("Approval rollback failed:", rollbackError);
      }
    }

    console.error("Payment approval failed:", error);

    return res.status(500).json({
      message: "Could not approve payment.",
    });
  } finally {
    client?.release();
  }
});



 // ================================
 // Customer Registration API
 // ================================

app.post("/api/auth/register", async (req, res) => {
  const { name, email, phone, password } = req.body ?? {};

  if (
    typeof name !== "string" ||
    typeof email !== "string" ||
    typeof password !== "string"
  ) {
    return res.status(400).json({
      message: "Name, email and password are required.",
    });
  }

  const cleanName = name.trim();
  const cleanEmail = email.trim().toLowerCase();
  const cleanPhone =
    typeof phone === "string" ? phone.trim() : null;

  if (
    cleanName.length < 2 ||
    cleanName.length > 100 ||
    !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail) ||
    cleanEmail.length > 255 ||
    password.length < 6 ||
    Buffer.byteLength(password, "utf8") > 72 ||
    (cleanPhone !== null && cleanPhone.length > 20)
  ) {
    return res.status(400).json({
      message:
        "Check your name, email, phone and password. Password must be 6–72 UTF-8 bytes.",
    });
  }

  try {
    const existing = await pool.query(
      "SELECT id, email_verified, name FROM public.users WHERE email = $1",
      [cleanEmail]
    );

    let user;
    if (existing.rows.length > 0) {
      if (existing.rows[0].email_verified === true) {
        return res.status(409).json({
          message:
            "An account with this email is already registered and verified. Please log in.",
        });
      }
      user = existing.rows[0];
      const passwordHash = await bcrypt.hash(password, 12);
      await pool.query(
        "UPDATE public.users SET password_hash = $1, name = $2 WHERE id = $3",
        [passwordHash, cleanName, user.id]
      );
    } else {
      const passwordHash = await bcrypt.hash(password, 12);
      const result = await pool.query(
        `INSERT INTO public.users
          (name, email, phone, password_hash, role, email_verified)
         VALUES ($1, $2, $3, $4, 'CUSTOMER', FALSE)
         RETURNING id, name, email, phone, role, created_at`,
        [cleanName, cleanEmail, cleanPhone, passwordHash]
      );
      user = result.rows[0];
    }

    const otp = generateOtp();
    const otpHash = await bcrypt.hash(otp, 10);

    // Invalidate previous unverified OTPs
    await pool.query(
      `UPDATE public.email_otps
       SET used_at = NOW()
       WHERE user_id = $1
         AND purpose = 'EMAIL_VERIFICATION'
         AND used_at IS NULL`,
      [user.id]
    );

    await pool.query(
      `INSERT INTO public.email_otps
        (user_id, purpose, otp_hash, expires_at)
       VALUES ($1, 'EMAIL_VERIFICATION', $2, NOW() + INTERVAL '5 minutes')`,
      [user.id, otpHash]
    );

    const emailSent = await sendOtpEmail(
      cleanEmail,
      otp,
      "EMAIL_VERIFICATION"
    );

    return res.status(201).json({
      success: true,
      message: emailSent
        ? "Registration successful. Check your email for the 6-digit verification code."
        : "Verification code sent to your email. Please check your inbox and spam folder.",
      email: cleanEmail,
      emailVerificationRequired: true,
    });
  } catch (error: any) {
    if (error.code === "23505") {
      return res.status(409).json({
        message: "An account with this email already exists.",
      });
    }

    console.error("Registration failed:", error);

    return res.status(500).json({
      message: "Could not register user.",
    });
  }
});
app.post("/api/auth/verify-email", async (req, res) => {
  const { email, otp } = req.body ?? {};

  if (
    typeof email !== "string" ||
    typeof otp !== "string" ||
    !/^\d{6}$/.test(otp)
  ) {
    return res.status(400).json({
      message: "Valid email and 6-digit verification code are required.",
    });
  }

  try {
    const userResult = await pool.query(
      `SELECT id, email_verified
       FROM public.users
       WHERE email = $1`,
      [email.trim().toLowerCase()]
    );

    if (userResult.rows.length === 0) {
      return res.status(400).json({
        message: "Invalid or expired verification code.",
      });
    }

    const user = userResult.rows[0];

    if (user.email_verified === true) {
      return res.json({ message: "Email is already verified." });
    }

    const otpResult = await pool.query(
      `SELECT id, otp_hash, attempts
       FROM public.email_otps
       WHERE user_id = $1
         AND purpose = 'EMAIL_VERIFICATION'
         AND used_at IS NULL
         AND expires_at > NOW()
       ORDER BY created_at DESC
       LIMIT 1`,
      [user.id]
    );

    if (otpResult.rows.length === 0) {
      return res.status(400).json({
        message: "Invalid or expired verification code.",
      });
    }

    const savedOtp = otpResult.rows[0];

    if (savedOtp.attempts >= 5) {
      return res.status(429).json({
        message: "Too many attempts. Please request a new code.",
      });
    }

    const matches = await bcrypt.compare(otp, savedOtp.otp_hash);

    if (!matches) {
      await pool.query(
        `UPDATE public.email_otps
         SET attempts = attempts + 1
         WHERE id = $1`,
        [savedOtp.id]
      );

      return res.status(400).json({
        message: "Invalid or expired verification code.",
      });
    }

    await pool.query(
      `UPDATE public.users
       SET email_verified = TRUE
       WHERE id = $1`,
      [user.id]
    );

    await pool.query(
      `UPDATE public.email_otps
       SET used_at = NOW()
       WHERE user_id = $1
         AND purpose = 'EMAIL_VERIFICATION'
         AND used_at IS NULL`,
      [user.id]
    );

    return res.json({ message: "Email verified successfully. You can now log in." });
  } catch (error) {
    console.error("Email verification failed:", error);

    return res.status(500).json({
      message: "Could not verify email.",
    });
  }
});

app.post("/api/auth/resend-verification", async (req, res) => {
  const { email } = req.body ?? {};

  if (typeof email !== "string" || !email.trim()) {
    return res.status(400).json({
      message: "Valid email is required.",
    });
  }

  try {
    const userResult = await pool.query(
      `SELECT id, email, email_verified
       FROM public.users
       WHERE email = $1`,
      [email.trim().toLowerCase()]
    );

    if (userResult.rows.length === 0) {
      return res.status(400).json({
        message: "Unable to send verification code.",
      });
    }

    const user = userResult.rows[0];

    if (user.email_verified === true) {
      return res.json({
        message: "Email is already verified.",
      });
    }

    const otp = generateOtp();
    const otpHash = await bcrypt.hash(otp, 10);

    await pool.query(
      `UPDATE public.email_otps
       SET used_at = NOW()
       WHERE user_id = $1
         AND purpose = 'EMAIL_VERIFICATION'
         AND used_at IS NULL`,
      [user.id]
    );

    await pool.query(
      `INSERT INTO public.email_otps
         (user_id, purpose, otp_hash, expires_at)
       VALUES ($1, 'EMAIL_VERIFICATION', $2,
               NOW() + INTERVAL '5 minutes')`,
      [user.id, otpHash]
    );

    const emailSent = await sendOtpEmail(
      user.email,
      otp,
      "EMAIL_VERIFICATION"
    );

    return res.json({
      success: true,
      message: emailSent
        ? "A new verification code has been sent to your email."
        : "A new verification code has been sent. Please check your inbox.",
    });
  } catch (error) {
    console.error("Resend verification failed:", error);

    return res.status(500).json({
      message: "Could not send verification code.",
    });
  }
});

 // ================================
 // Customer Login API
 // ================================
app.post("/api/auth/login", async (req, res) => {
  const { email, password } = req.body ?? {};

  if (
    typeof email !== "string" ||
    typeof password !== "string" ||
    !email.trim() ||
    !password ||
    Buffer.byteLength(password, "utf8") > 72
  ) {
    return res.status(400).json({
      message: "Valid email and password are required.",
    });
  }

  try {
    const result = await pool.query(
      `SELECT id, name, email, password_hash, role, email_verified
       FROM public.users
       WHERE email = $1`,
      [email.trim().toLowerCase()]
    );

    if (result.rows.length === 0) {
      return res.status(401).json({
        message: "Invalid email or password.",
      });
    }

    const user = result.rows[0];

if (user.email_verified !== true) {
  return res.status(403).json({
    message: "Please verify your email before logging in.",
    emailVerificationRequired: true,
  });
}

const passwordMatches = await bcrypt.compare(
  password,
  user.password_hash
);

    if (!passwordMatches) {
      return res.status(401).json({
        message: "Invalid email or password.",
      });
    }

    const jwtSecret = process.env.JWT_SECRET;

    if (!jwtSecret || jwtSecret.length < 32) {
      console.error("JWT_SECRET is missing or too short.");

      return res.status(500).json({
        message: "Login service is not configured.",
      });
    }

    const token = jwt.sign(
      {
        role: user.role,
      },
      jwtSecret,
      {
        subject: String(user.id),
        expiresIn: "1h",
        issuer: "v2nexus-api",
        audience: "v2nexus-customers",
      }
    );

    return res.json({
      message: "Login successful.",
      token,
      expiresIn: 3600,
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role,
      },
    });
  } catch (error) {
    console.error("Login failed:", error);

    return res.status(500).json({
      message: "Could not log in.",
    });
  }
});
/* =====================================
   GOOGLE OAUTH (LOGIN / REGISTRATION / ADMIN)
===================================== */
app.post("/api/auth/google", async (req, res) => {
  try {
    const { credential, target, simulatedUser } = req.body ?? {};
    const loginTarget = target === "admin" ? "admin" : "user";

    let email = "";
    let name = "";
    let picture = "";
    let googleId = "";

    // 1. Verify with Google's official tokeninfo endpoint if token provided
    if (typeof credential === "string" && credential.trim().length > 10) {
      try {
        const tokenRes = await fetch(
          `https://oauth2.googleapis.com/tokeninfo?id_token=${encodeURIComponent(credential.trim())}`
        );
        if (tokenRes.ok) {
          const tokenData = await tokenRes.json();
          email = String(tokenData.email || "").trim().toLowerCase();
          name = String(tokenData.name || "").trim();
          picture = String(tokenData.picture || "").trim();
          googleId = String(tokenData.sub || "").trim();
        } else {
          // Fallback to JWT payload decode if tokeninfo fails
          const parts = credential.split(".");
          if (parts.length === 3) {
            const payload = JSON.parse(Buffer.from(parts[1], "base64").toString("utf-8"));
            email = String(payload.email || "").trim().toLowerCase();
            name = String(payload.name || "").trim();
            picture = String(payload.picture || "").trim();
            googleId = String(payload.sub || "").trim();
          }
        }
      } catch (tokenErr) {
        console.warn("Google token verification notice:", tokenErr);
      }
    }

    // 2. Simulated/Local fallback when testing locally without Google Cloud Client ID
    if (!email && simulatedUser && typeof simulatedUser.email === "string") {
      email = simulatedUser.email.trim().toLowerCase();
      name = typeof simulatedUser.name === "string" && simulatedUser.name.trim()
        ? simulatedUser.name.trim()
        : email.split("@")[0];
      googleId = `simulated_${Date.now()}`;
    }

    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return res.status(400).json({
        message: "Valid Google email could not be retrieved from login request.",
      });
    }

    // 3. Authorized Admin Check
    const configuredAdminEmails = (process.env.ADMIN_EMAILS || "v2nexus.team@gmail.com")
      .split(",")
      .map((e) => e.trim().toLowerCase())
      .filter(Boolean);

    const isConfiguredAdmin = configuredAdminEmails.includes(email);

    // If logging into Admin Portal
    if (loginTarget === "admin") {
      const existingUserRes = await pool.query(
        "SELECT id, name, email, role, email_verified FROM public.users WHERE LOWER(email) = $1",
        [email]
      );
      const isDbAdmin = existingUserRes.rows.length > 0 &&
        (existingUserRes.rows[0].role?.toLowerCase() === "admin" || existingUserRes.rows[0].role === "ADMIN");

      if (!isConfiguredAdmin && !isDbAdmin) {
        return res.status(403).json({
          message: `Access Denied: The Google account (${email}) is not authorized as an administrator. Please add this email to ADMIN_EMAILS in .env or contact the superadmin.`,
        });
      }

      let adminUser;
      if (existingUserRes.rows.length > 0) {
        adminUser = existingUserRes.rows[0];
        if (adminUser.role !== "admin" && adminUser.role !== "ADMIN") {
          await pool.query(
            "UPDATE public.users SET role = 'ADMIN', email_verified = TRUE WHERE id = $1",
            [adminUser.id]
          );
          adminUser.role = "admin";
        }
      } else {
        const dummyHash = await bcrypt.hash(`GOOGLE_AUTH_${crypto.randomUUID()}`, 10);
        const newAdminRes = await pool.query(
          `INSERT INTO public.users (name, email, password_hash, role, email_verified)
           VALUES ($1, $2, $3, 'ADMIN', TRUE)
           RETURNING id, name, email, role, email_verified`,
          [name || "Super Admin", email, dummyHash]
        );
        adminUser = newAdminRes.rows[0];
      }

      const jwtSecret = process.env.JWT_SECRET;
      if (!jwtSecret || jwtSecret.length < 32) {
        return res.status(500).json({ message: "JWT secret is not configured." });
      }

      const token = jwt.sign(
        { role: "admin" },
        jwtSecret,
        {
          subject: String(adminUser.id),
          expiresIn: "24h",
          issuer: "v2nexus-api",
          audience: "v2nexus-customers",
        }
      );

      return res.json({
        success: true,
        message: "Admin Google authentication successful.",
        token,
        user: {
          id: String(adminUser.id),
          name: adminUser.name || name || "Super Admin",
          email: adminUser.email,
          role: "admin",
          picture,
        },
      });
    }

    // 4. Standard User Google Login / Registration
    const existingUserRes = await pool.query(
      "SELECT id, name, email, role, email_verified FROM public.users WHERE LOWER(email) = $1",
      [email]
    );

    let user;
    let isNewUser = false;

    if (existingUserRes.rows.length > 0) {
      user = existingUserRes.rows[0];
      // Google confirms email is verified, so guarantee email_verified is true
      if (!user.email_verified) {
        await pool.query(
          "UPDATE public.users SET email_verified = TRUE WHERE id = $1",
          [user.id]
        );
        user.email_verified = true;
      }
      if (isConfiguredAdmin && user.role !== "admin" && user.role !== "ADMIN") {
        await pool.query(
          "UPDATE public.users SET role = 'ADMIN' WHERE id = $1",
          [user.id]
        );
        user.role = "admin";
      }
    } else {
      isNewUser = true;
      const assignedRole = isConfiguredAdmin ? "ADMIN" : "CUSTOMER";
      const dummyHash = await bcrypt.hash(`GOOGLE_AUTH_${crypto.randomUUID()}`, 10);
      const insertRes = await pool.query(
        `INSERT INTO public.users (name, email, password_hash, role, email_verified)
         VALUES ($1, $2, $3, $4, TRUE)
         RETURNING id, name, email, role, email_verified`,
        [name || email.split("@")[0], email, dummyHash, assignedRole]
      );
      user = insertRes.rows[0];
    }

    const jwtSecret = process.env.JWT_SECRET;
    if (!jwtSecret || jwtSecret.length < 32) {
      return res.status(500).json({ message: "JWT secret is not configured." });
    }

    const mappedRole = (String(user.role).toUpperCase() === "ADMIN") ? "admin" : "user";
    const token = jwt.sign(
      { role: user.role },
      jwtSecret,
      {
        subject: String(user.id),
        expiresIn: "7d",
        issuer: "v2nexus-api",
        audience: "v2nexus-customers",
      }
    );

    return res.json({
      success: true,
      message: isNewUser
        ? "Account created and verified with Google!"
        : "Google login successful.",
      isNewUser,
      token,
      user: {
        id: String(user.id),
        name: user.name,
        email: user.email,
        role: mappedRole,
        picture,
      },
    });
  } catch (error) {
    console.error("Google authentication error:", error);
    return res.status(500).json({
      message: "Google authentication failed. Please try again or use standard login.",
    });
  }
});

// Admin Authorized Emails Management (receiver list)
// Add new authorized admin email
app.post("/api/admin/authorized-emails", async (req, res) => {
  try {
    const { email, name } = req.body ?? {};
    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return res.status(400).json({ message: "Valid email is required." });
    }
    const cleanEmail = email.trim().toLowerCase();
    const cleanName = (name && typeof name === "string" && name.trim()) ? name.trim() : "Super Admin";

    const existing = await pool.query(
      "SELECT id, role FROM public.users WHERE LOWER(email) = $1",
      [cleanEmail]
    );

    if (existing.rows.length > 0) {
      await pool.query(
        "UPDATE public.users SET role = 'ADMIN', email_verified = TRUE WHERE id = $1",
        [existing.rows[0].id]
      );
    } else {
      const dummyHash = await bcrypt.hash(`ADMIN_AUTH_${crypto.randomUUID()}`, 10);
      await pool.query(
        `INSERT INTO public.users (name, email, password_hash, role, email_verified)
         VALUES ($1, $2, $3, 'ADMIN', TRUE)`,
        [cleanName, cleanEmail, dummyHash]
      );
    }

    res.json({
      success: true,
      message: `Successfully authorized ${cleanEmail} as Super Admin! They can now sign in with Google directly.`,
      email: cleanEmail,
    });
  } catch (error) {
    console.error("Failed to add authorized admin email:", error);
    res.status(500).json({ message: "Could not add admin email." });
  }
});

// Remove admin privileges for an email
app.delete("/api/admin/authorized-emails/:email", async (req, res) => {
  try {
    const email = req.params.email?.trim().toLowerCase();
    if (!email) {
      return res.status(400).json({ message: "Email parameter is required." });
    }
    await pool.query(
      "UPDATE public.users SET role = 'CUSTOMER' WHERE LOWER(email) = $1",
      [email]
    );
    res.json({
      success: true,
      message: `Admin privileges revoked for ${email}.`,
    });
  } catch (error) {
    console.error("Failed to revoke admin email:", error);
    res.status(500).json({ message: "Could not remove admin email." });
  }
});

app.get("/api/admin/authorized-emails", async (_req, res) => {
  try {
    const configuredAdminEmails = (process.env.ADMIN_EMAILS || "v2nexus.team@gmail.com")
      .split(",")
      .map((e) => e.trim().toLowerCase())
      .filter(Boolean);

    const dbAdmins = await pool.query(
      "SELECT id, name, email, role, created_at FROM public.users WHERE role ILIKE 'admin'"
    );

    const allAdmins = Array.from(
      new Set([
        ...configuredAdminEmails,
        ...dbAdmins.rows.map((r) => r.email.toLowerCase()),
      ])
    );

    res.json({
      configuredInEnv: configuredAdminEmails,
      databaseAdmins: dbAdmins.rows,
      allAuthorizedEmails: allAdmins,
    });
  } catch (error) {
    console.error("Failed to fetch authorized admin emails:", error);
    res.status(500).json({ message: "Failed to load admin emails." });
  }
});


app.get("/api/auth/me", requireAuth, async (req, res) => {
  const authReq = req as AuthRequest;

  try {
    const result = await pool.query(
      `SELECT id, name, email, role
       FROM public.users
       WHERE id = $1`,
      [authReq.user!.id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({
        message: "User not found.",
      });
    }

    return res.json({ user: result.rows[0] });
  } catch (error) {
    console.error("Failed to get current user:", error);
    return res.status(500).json({
      message: "Could not retrieve user.",
    });
  }
});

/* =====================================
   FORGOT PASSWORD - SEND OTP
===================================== */

app.post("/api/auth/forgot-password", async (req, res) => {
  const email =
    typeof req.body?.email === "string"
      ? req.body.email.trim().toLowerCase()
      : "";

  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return res.status(400).json({
      message: "Please enter a valid email address.",
    });
  }

  try {
    const result = await pool.query(
      `SELECT id, email_verified
       FROM public.users
       WHERE email = $1`,
      [email]
    );

    // Do not reveal whether an account exists.
    if (
      result.rows.length === 0 ||
      result.rows[0].email_verified !== true
    ) {
      return res.json({
        message:
          "If a verified account exists for this email, a reset code will be sent.",
      });
    }

    const user = result.rows[0];
    const otp = generateOtp();
    const otpHash = await bcrypt.hash(otp, 10);

    await pool.query(
      `UPDATE public.email_otps
       SET used_at = NOW()
       WHERE user_id = $1
         AND purpose = 'PASSWORD_RESET'
         AND used_at IS NULL`,
      [user.id]
    );

    await pool.query(
      `INSERT INTO public.email_otps
        (user_id, purpose, otp_hash, expires_at)
       VALUES ($1, 'PASSWORD_RESET', $2, NOW() + INTERVAL '5 minutes')`,
      [user.id, otpHash]
    );

    let emailSent = false;
    try {
      emailSent = await sendOtpEmail(email, otp, "PASSWORD_RESET");
    } catch (emailError) {
      console.error("Password reset email delivery failed (dev OTP available):", emailError);
    }

    return res.json({
      success: true,
      message: "If a verified account exists for this email, a reset code has been sent.",
    });
  } catch (error) {
    console.error("Forgot password failed:", error);

    return res.status(500).json({
      message: "Could not process your request.",
    });
  }
});


/* =====================================
   RESET PASSWORD - VERIFY OTP
===================================== */

app.post("/api/auth/reset-password", async (req, res) => {
  const email =
    typeof req.body?.email === "string"
      ? req.body.email.trim().toLowerCase()
      : "";

  const otp =
    typeof req.body?.otp === "string"
      ? req.body.otp.trim()
      : "";

  const password =
    typeof req.body?.password === "string"
      ? req.body.password
      : "";

  if (
    !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) ||
    !/^\d{6}$/.test(otp) ||
    password.length < 6
  ) {
    return res.status(400).json({
      message:
        "Valid email, 6-digit code, and password of at least 6 characters are required.",
    });
  }

  try {
    const userResult = await pool.query(
      `SELECT id, email_verified
       FROM public.users
       WHERE email = $1`,
      [email]
    );

    if (
      userResult.rows.length === 0 ||
      userResult.rows[0].email_verified !== true
    ) {
      return res.status(400).json({
        message: "Invalid or expired reset code.",
      });
    }

    const user = userResult.rows[0];

    const otpResult = await pool.query(
      `SELECT id, otp_hash, attempts
       FROM public.email_otps
       WHERE user_id = $1
         AND purpose = 'PASSWORD_RESET'
         AND used_at IS NULL
         AND expires_at > NOW()
       ORDER BY created_at DESC
       LIMIT 1`,
      [user.id]
    );

    if (otpResult.rows.length === 0) {
      return res.status(400).json({
        message: "Invalid or expired reset code.",
      });
    }

    const savedOtp = otpResult.rows[0];

    if (savedOtp.attempts >= 5) {
      return res.status(429).json({
        message: "Too many attempts. Request a new reset code.",
      });
    }

    const matches = await bcrypt.compare(otp, savedOtp.otp_hash);

    if (!matches) {
      await pool.query(
        `UPDATE public.email_otps
         SET attempts = attempts + 1
         WHERE id = $1`,
        [savedOtp.id]
      );

      return res.status(400).json({
        message: "Invalid or expired reset code.",
      });
    }

    const passwordHash = await bcrypt.hash(password, 12);

    // Update the password and consume the OTP atomically.
    const client = await pool.connect();

    try {
      await client.query("BEGIN");

      const lockResult = await client.query(
        `SELECT id, otp_hash, attempts
         FROM public.email_otps
         WHERE id = $1
           AND user_id = $2
           AND purpose = 'PASSWORD_RESET'
           AND used_at IS NULL
           AND expires_at > NOW()
         FOR UPDATE`,
        [savedOtp.id, user.id]
      );

      if (
        lockResult.rows.length === 0 ||
        lockResult.rows[0].attempts >= 5 ||
        !(await bcrypt.compare(otp, lockResult.rows[0].otp_hash))
      ) {
        await client.query("ROLLBACK");

        return res.status(400).json({
          message: "Invalid or expired reset code.",
        });
      }

      await client.query(
        `UPDATE public.users
         SET password_hash = $1
         WHERE id = $2`,
        [passwordHash, user.id]
      );

      await client.query(
        `UPDATE public.email_otps
         SET used_at = NOW()
         WHERE id = $1`,
        [savedOtp.id]
      );

      await client.query("COMMIT");
    } catch (transactionError) {
      await client.query("ROLLBACK");
      throw transactionError;
    } finally {
      client.release();
    }

    return res.json({
      message: "Password reset successful. You can now log in.",
    });
  } catch (error) {
    console.error("Reset password failed:", error);

    return res.status(500).json({
      message: "Could not reset password.",
    });
  }
});
// ================================
//  Start backend server
// ================================
const PORT = Number(process.env.PORT) || 3001;

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
