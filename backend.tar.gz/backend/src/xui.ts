import https from 'https';
import querystring from 'querystring';

export interface XuiClientConfig {
  uuid: string;
  email: string;
  limitIp?: number;
  totalBytes?: number; // total traffic in bytes (0 = unlimited)
  expiryTimeMs?: number; // expiry in ms
  enable?: boolean;
  subId?: string;
  flow?: string;
}

export interface InboundClientResult {
  success: boolean;
  msg?: string;
  uuid: string;
  vlessUrl: string;
  serverLocation: string;
}

export class XuiService {
  private baseUrl: string;
  private basePath: string;
  private host: string;
  private port: number;
  private username: string;
  private password: string;
  private inboundId: number;

  private sessionCookie: string | null = null;
  private csrfToken: string | null = null;
  private sessionExpiresAt: number = 0;

  constructor() {
    this.host = process.env.XUI_SERVER_HOST || 'virtual-internet-access.duckdns.org';
    this.port = parseInt(process.env.XUI_PORT || '2026', 10);
    this.basePath = process.env.XUI_BASE_PATH || '/uOJrOfi5L20iAl9Fth';
    this.baseUrl = `https://${this.host}:${this.port}${this.basePath}`;
    this.username = process.env.XUI_USERNAME || 'admin-malka';
    this.password = process.env.XUI_PASSWORD || 'Cr2o7Dinithi3X-UI';
    this.inboundId = parseInt(process.env.XUI_INBOUND_ID || '1', 10);
  }

  /**
   * Helper HTTPS request with agent that ignores self-signed certificates
   */
  private makeRequest(
    path: string,
    method: 'GET' | 'POST',
    headers: Record<string, string>,
    bodyData?: string
  ): Promise<{ statusCode: number; headers: Record<string, any>; body: string }> {
    return new Promise((resolve, reject) => {
      const fullPath = path.startsWith(this.basePath) ? path : `${this.basePath}${path}`;
      const req = https.request(
        {
          hostname: this.host,
          port: this.port,
          path: fullPath,
          method,
          rejectUnauthorized: false,
          headers,
        },
        (res) => {
          let body = '';
          res.on('data', (chunk) => (body += chunk));
          res.on('end', () => {
            resolve({
              statusCode: res.statusCode || 0,
              headers: res.headers,
              body,
            });
          });
        }
      );

      req.on('error', (err) => reject(err));

      if (bodyData) {
        req.write(bodyData);
      }
      req.end();
    });
  }

  /**
   * Authenticate with 3X-UI panel and acquire session cookie + CSRF token
   */
  public async login(): Promise<boolean> {
    try {
      // Step 1: GET base path to establish initial session cookie
      const initRes = await this.makeRequest('/', 'GET', {});
      const rawCookies = initRes.headers['set-cookie'] || [];
      const cookieStr = rawCookies.map((c: string) => c.split(';')[0]).join('; ');

      // Step 2: GET /csrf-token
      const csrfRes = await this.makeRequest('/csrf-token', 'GET', {
        Cookie: cookieStr,
        'X-Requested-With': 'XMLHttpRequest',
      });

      let csrf = '';
      try {
        const parsed = JSON.parse(csrfRes.body);
        if (parsed.success && parsed.obj) {
          csrf = parsed.obj;
        }
      } catch (e) {
        console.warn('[3X-UI] Failed to parse CSRF response:', csrfRes.body);
      }

      // Step 3: POST /login with credentials
      const form = querystring.stringify({
        username: this.username,
        password: this.password,
      });

      const loginRes = await this.makeRequest(
        '/login',
        'POST',
        {
          Cookie: cookieStr,
          'X-CSRF-Token': csrf,
          'X-Requested-With': 'XMLHttpRequest',
          'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
          'Content-Length': String(Buffer.byteLength(form)),
        },
        form
      );

      let loginSuccess = false;
      try {
        const parsed = JSON.parse(loginRes.body);
        loginSuccess = Boolean(parsed.success);
      } catch (e) {
        loginSuccess = loginRes.body.includes('"success":true');
      }

      if (loginSuccess) {
        // Collect updated login session cookies (do not keep old unauth cookie)
        const loginCookies = loginRes.headers['set-cookie'] || [];
        const authCookie = loginCookies.length > 0
          ? loginCookies.map((c: string) => c.split(';')[0]).join('; ')
          : cookieStr;

        this.sessionCookie = authCookie;
        this.csrfToken = csrf;
        this.sessionExpiresAt = Date.now() + 60 * 60 * 1000; // 1 hour validity cache
        console.log('[3X-UI] Successfully authenticated to panel.');
        return true;
      } else {
        console.warn('[3X-UI] Authentication failed. Response:', loginRes.body);
        return false;
      }
    } catch (err) {
      console.error('[3X-UI] Login error:', err);
      return false;
    }
  }

  /**
   * Ensure active session before API calls
   */
  private async ensureAuthenticated(): Promise<boolean> {
    if (this.sessionCookie && this.sessionExpiresAt > Date.now()) {
      return true;
    }
    return await this.login();
  }

  /**
   * Construct standard VLESS URI for Inbound #1 (Cyberx, Port 443, TLS, gRPC) with dynamic SNI & ALPN (h2, http/1.1)
   */
  public generateVlessUrl(
    clientUuid: string,
    remarkName: string = 'SecureVPN',
    sniDomain: string = 'aka.ms'
  ): string {
    const cleanRemark = remarkName.replace(/[^a-zA-Z0-9_-]/g, '-');
    const sni = (sniDomain && sniDomain.trim()) ? sniDomain.trim() : 'aka.ms';
    const remarkSuffix = cleanRemark ? `#Cyberx-${cleanRemark}` : '';
    return `vless://${clientUuid}@${this.host}:443/?encryption=none&flow=none&security=tls&fp=chrome&sni=${sni}&alpn=h2%2c+http%2f1.1&type=grpc&mode=gun&serviceName=grpc-service${remarkSuffix}`;
  }

  /**
   * Add a new client directly to Inbound #1 on the live 3X-UI VPS
   */
  public async addClient(
    config: XuiClientConfig,
    remarkName: string = 'SecureVPN',
    sniDomain: string = 'aka.ms'
  ): Promise<InboundClientResult> {
    const vlessUrl = this.generateVlessUrl(config.uuid, remarkName, sniDomain);
    const serverLocation = `${this.host}:443 (Cyberx - VLESS gRPC TLS | SNI: ${sniDomain || 'aka.ms'})`;

    const isAuthenticated = await this.ensureAuthenticated();
    if (!isAuthenticated) {
      console.warn('[3X-UI] Cannot add client: panel auth not active. Returning provisioned config for dashboard display.');
      return {
        success: false,
        msg: 'Panel authentication pending - using direct connection parameters',
        uuid: config.uuid,
        vlessUrl,
        serverLocation,
      };
    }

    try {
      // 3X-UI verified API: POST /panel/api/clients/add
      const payload = JSON.stringify({
        client: {
          id: config.uuid,
          email: config.email,
          totalGB: config.totalBytes ?? 0,
          expiryTime: config.expiryTimeMs ?? 0,
          tgId: 0,
          limitIp: config.limitIp ?? 2,
          limitHwid: 0,
          enable: config.enable ?? true,
        },
        inboundIds: [this.inboundId],
      });

      const res = await this.makeRequest(
        '/panel/api/clients/add',
        'POST',
        {
          Cookie: this.sessionCookie || '',
          'X-CSRF-Token': this.csrfToken || '',
          'X-Requested-With': 'XMLHttpRequest',
          'Content-Type': 'application/json',
          'Content-Length': String(Buffer.byteLength(payload)),
        },
        payload
      );

      let resObj: any = {};
      try {
        resObj = JSON.parse(res.body);
      } catch (e) {
        resObj = { success: res.body.includes('"success":true') };
      }

      if (resObj.success) {
        console.log(`[3X-UI] Real client ${config.uuid} (${config.email}) successfully provisioned on Inbound #${this.inboundId}!`);
        return {
          success: true,
          msg: 'Client created successfully in 3X-UI VPS',
          uuid: config.uuid,
          vlessUrl,
          serverLocation,
        };
      } else {
        console.warn('[3X-UI] addClient returned non-success:', res.body);
        return {
          success: false,
          msg: resObj.msg || '3X-UI rejected addClient request',
          uuid: config.uuid,
          vlessUrl,
          serverLocation,
        };
      }
    } catch (err: any) {
      console.error('[3X-UI] Failed to add client to VPS inbound:', err);
      return {
        success: false,
        msg: err.message || 'Network error communicating with 3X-UI',
        uuid: config.uuid,
        vlessUrl,
        serverLocation,
      };
    }
  }

  /**
   * Delete a client from 3X-UI (used when order is rejected/cancelled)
   */
  public async deleteClient(emailOrUuid: string): Promise<boolean> {
    const isAuthenticated = await this.ensureAuthenticated();
    if (!isAuthenticated) return false;

    try {
      const res = await this.makeRequest(
        `/panel/api/clients/del/${encodeURIComponent(emailOrUuid)}`,
        'POST',
        {
          Cookie: this.sessionCookie || '',
          'X-CSRF-Token': this.csrfToken || '',
          'X-Requested-With': 'XMLHttpRequest',
        }
      );
      return res.body.includes('"success":true');
    } catch (err) {
      console.error('[3X-UI] delClient error:', err);
      return false;
    }
  }

  /**
   * Fetch live traffic metrics for a client by email
   */
  public async getClientTraffic(email: string): Promise<any> {
    const isAuthenticated = await this.ensureAuthenticated();
    if (!isAuthenticated) return null;

    try {
      const res = await this.makeRequest(
        `/panel/api/clients/traffic/${encodeURIComponent(email)}`,
        'GET',
        {
          Cookie: this.sessionCookie || '',
          'X-Requested-With': 'XMLHttpRequest',
        }
      );
      return JSON.parse(res.body);
    } catch (err) {
      return null;
    }
  }

  /**
   * Fetch all inbound clients live stats from 3X-UI VPS
   */
  public async getAllClientStats(): Promise<Record<string, any>> {
    const isAuthenticated = await this.ensureAuthenticated();
    if (!isAuthenticated) return {};

    try {
      const res = await this.makeRequest(
        '/panel/api/inbounds/list',
        'GET',
        {
          Cookie: this.sessionCookie || '',
          'X-Requested-With': 'XMLHttpRequest',
        }
      );
      const data = JSON.parse(res.body);
      const inbounds = data.obj || [];
      const statsMap: Record<string, any> = {};

      for (const inb of inbounds) {
        const clientStats = inb.clientStats || [];
        for (const cs of clientStats) {
          const item = {
            id: cs.id,
            inboundId: cs.inboundId,
            uuid: cs.uuid,
            email: cs.email,
            up: cs.up || 0,
            down: cs.down || 0,
            total: cs.total || 0,
            enable: cs.enable,
            expiryTime: cs.expiryTime || 0,
            lastOnline: cs.lastOnline || 0,
          };
          if (cs.email) statsMap[String(cs.email).toLowerCase()] = item;
          if (cs.uuid) statsMap[String(cs.uuid).toLowerCase()] = item;
        }
      }
      return statsMap;
    } catch (err) {
      console.error('[3X-UI] getAllClientStats error:', err);
      return {};
    }
  }
}

export const xuiService = new XuiService();
