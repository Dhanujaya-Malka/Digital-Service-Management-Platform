import { xuiService } from './xui';

async function getSpec() {
  await xuiService.login();
  const res = await (xuiService as any).makeRequest(
    '/panel/api/openapi.json',
    'GET',
    {
      Cookie: (xuiService as any).sessionCookie,
      'X-Requested-With': 'XMLHttpRequest',
    }
  );
  try {
    const spec = JSON.parse(res.body);
    const paths = Object.keys(spec.paths || {});
    console.log('Total routes:', paths.length);
    const clientPaths = paths.filter((p) => p.includes('client') || p.includes('inbound'));
    console.log('Client & Inbound routes:');
    clientPaths.forEach((p) => {
      const methods = Object.keys(spec.paths[p]);
      console.log(methods.join(',').toUpperCase().padEnd(10), p);
    });
  } catch (e: any) {
    console.error('Parse error:', e.message);
  }
}

getSpec();
