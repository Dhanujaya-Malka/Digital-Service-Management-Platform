import nodemailer from "nodemailer";
import { randomInt } from "node:crypto";
import dotenv from "dotenv";

dotenv.config();

function getTransporter() {
  const smtpUser = process.env.SMTP_USER || "v2nexus.team@gmail.com";
  const smtpPassword = process.env.SMTP_APP_PASSWORD;

  if (!smtpUser || !smtpPassword) {
    return null;
  }

  return nodemailer.createTransport({
    host: "smtp.gmail.com",
    port: 587,
    secure: false,
    connectionTimeout: 4000,
    greetingTimeout: 4000,
    socketTimeout: 4000,
    auth: {
      user: smtpUser,
      pass: smtpPassword.replace(/\s/g, ""),
    },
  });
}

export function generateOtp(): string {
  return randomInt(0, 1_000_000)
    .toString()
    .padStart(6, "0");
}

function getCreativeEmailHtml(otp: string, purpose: "EMAIL_VERIFICATION" | "PASSWORD_RESET", recipientEmail: string): string {
  const isVerification = purpose === "EMAIL_VERIFICATION";
  const title = isVerification ? "Verify Your Email Address" : "Password Reset Authorization";
  const badgeText = isVerification ? "NEW ACCOUNT VERIFICATION" : "SECURITY PASSWORD RESET";
  const description = isVerification
    ? "Welcome to <strong>V2Nexus</strong>! You are just one step away from activating your high-speed, military-grade secure VPN account. Please enter the verification code below on the confirmation screen."
    : "We received an official request to reset the password for your <strong>V2Nexus</strong> account. Enter the verification code below to establish your new password.";

  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${title}</title>
</head>
<body style="margin: 0; padding: 0; background-color: #060913; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; color: #f1f5f9;">
  <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background-color: #060913; padding: 40px 16px;">
    <tr>
      <td align="center">
        <!-- Main Card Container -->
        <table role="presentation" width="100%" style="max-width: 560px; background: linear-gradient(180deg, #0e1526 0%, #0a0f1d 100%); border: 1px solid #1e293b; border-radius: 20px; overflow: hidden; box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.7);" cellspacing="0" cellpadding="0">
          
          <!-- Top Glowing Cyan Gradient Bar -->
          <tr>
            <td style="height: 4px; background: linear-gradient(90deg, #06b6d4 0%, #3b82f6 50%, #8b5cf6 100%);"></td>
          </tr>

          <!-- Header with Logo -->
          <tr>
            <td style="padding: 36px 36px 20px 36px; text-align: center;">
              <table role="presentation" align="center" cellspacing="0" cellpadding="0">
                <tr>
                  <td style="background: rgba(6, 182, 212, 0.12); border: 1px solid rgba(6, 182, 212, 0.35); border-radius: 14px; padding: 10px 14px;">
                    <span style="font-size: 22px; line-height: 1;">🛡️</span>
                    <span style="font-size: 18px; font-weight: 800; color: #ffffff; letter-spacing: 1.5px; margin-left: 8px;">V2NEXUS</span>
                    <span style="font-size: 11px; font-weight: 700; color: #06b6d4; background: rgba(6, 182, 212, 0.2); padding: 2px 7px; border-radius: 6px; margin-left: 6px; letter-spacing: 0.5px;">SECURE VPN</span>
                  </td>
                </tr>
              </table>
            </td>
          </tr>

          <!-- Title & Badge -->
          <tr>
            <td style="padding: 0 36px; text-align: center;">
              <div style="display: inline-block; background: ${isVerification ? 'rgba(6, 182, 212, 0.15)' : 'rgba(239, 68, 68, 0.15)'}; border: 1px solid ${isVerification ? 'rgba(6, 182, 212, 0.35)' : 'rgba(239, 68, 68, 0.35)'}; border-radius: 20px; padding: 5px 14px; margin-bottom: 14px;">
                <span style="color: ${isVerification ? '#22d3ee' : '#f87171'}; font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 1px;">
                  ${badgeText}
                </span>
              </div>
              <h1 style="margin: 0 0 12px 0; font-size: 24px; font-weight: 800; color: #ffffff; letter-spacing: -0.5px;">
                ${title}
              </h1>
              <p style="margin: 0; font-size: 14px; line-height: 1.6; color: #94a3b8;">
                ${description}
              </p>
            </td>
          </tr>

          <!-- CREATIVE OTP DISPLAY BOX -->
          <tr>
            <td style="padding: 28px 36px;">
              <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background: linear-gradient(135deg, #0b1120 0%, #111a30 100%); border: 2px solid #06b6d4; border-radius: 16px; padding: 24px 16px; text-align: center; box-shadow: 0 8px 30px rgba(6, 182, 212, 0.18);">
                <tr>
                  <td align="center">
                    <div style="color: #64748b; font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 2px; margin-bottom: 8px;">
                      ONE-TIME VERIFICATION CODE
                    </div>
                    <div style="font-family: 'Courier New', Courier, Consolas, monospace; font-size: 40px; font-weight: 900; letter-spacing: 12px; color: #38bdf8; text-shadow: 0 0 25px rgba(56, 189, 248, 0.5); padding: 8px 0;">
                      ${otp}
                    </div>
                    <div style="display: inline-block; background: rgba(6, 182, 212, 0.12); border: 1px solid rgba(6, 182, 212, 0.25); border-radius: 20px; padding: 5px 14px; margin-top: 10px;">
                      <span style="color: #22d3ee; font-size: 12px; font-weight: 600;">⏱️ Valid for 5 minutes only</span>
                    </div>
                  </td>
                </tr>
              </table>
            </td>
          </tr>

          <!-- Recipient Pill & Security Notice -->
          <tr>
            <td style="padding: 0 36px 28px 36px;">
              <div style="background: rgba(15, 23, 42, 0.6); border: 1px solid #1e293b; border-radius: 12px; padding: 14px 18px; margin-bottom: 20px;">
                <table role="presentation" width="100%" cellspacing="0" cellpadding="0">
                  <tr>
                    <td style="color: #94a3b8; font-size: 12px;">This request was issued for:</td>
                    <td align="right" style="color: #f1f5f9; font-size: 12px; font-family: monospace; font-weight: 700;">${recipientEmail}</td>
                  </tr>
                </table>
              </div>

              <!-- Security Advisory -->
              <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background: rgba(245, 158, 11, 0.08); border-left: 3px solid #f59e0b; border-radius: 4px; padding: 12px 14px;">
                <tr>
                  <td>
                    <p style="margin: 0; color: #fbbf24; font-size: 12px; font-weight: 600; line-height: 1.5;">
                      🔒 <strong>Security Notice:</strong> Never share this code with anyone. V2Nexus team members will never ask for your verification code. If you did not make this request, you can safely ignore this email.
                    </p>
                  </td>
                </tr>
              </table>
            </td>
          </tr>

          <!-- Divider -->
          <tr>
            <td style="border-top: 1px solid #1e293b; padding: 0;"></td>
          </tr>

          <!-- Footer -->
          <tr>
            <td style="padding: 24px 36px 32px 36px; text-align: center; color: #64748b; font-size: 11px; line-height: 1.6;">
              <p style="margin: 0 0 6px 0; color: #94a3b8; font-weight: 600;">
                V2Nexus Secure Communication Network
              </p>
              <p style="margin: 0 0 10px 0;">
                High-Speed Encrypted Cloud Infrastructure • Automated Client Delivery System
              </p>
              <p style="margin: 0; color: #475569; font-size: 10px;">
                Sender: <span style="color: #06b6d4;">v2nexus.team@gmail.com</span> • &copy; ${new Date().getFullYear()} V2Nexus. All rights reserved.
              </p>
            </td>
          </tr>

        </table>
      </td>
    </tr>
  </table>
</body>
</html>`;
}

export async function sendOtpEmail(
  email: string,
  otp: string,
  purpose: "EMAIL_VERIFICATION" | "PASSWORD_RESET"
): Promise<boolean> {
  const smtpUser = process.env.SMTP_USER || "v2nexus.team@gmail.com";
  const isVerification = purpose === "EMAIL_VERIFICATION";

  console.log(`[AUTH OTP] ==========================================`);
  console.log(`[AUTH OTP] Sender: ${smtpUser}`);
  console.log(`[AUTH OTP] Recipient: ${email}`);
  console.log(`[AUTH OTP] Purpose: ${purpose}`);
  console.log(`[AUTH OTP] 6-Digit Code: >>> ${otp} <<<`);
  console.log(`[AUTH OTP] ==========================================`);

  try {
    const transporter = getTransporter();
    if (!transporter || !smtpUser) {
      console.warn("[AUTH OTP] SMTP credentials not set. Code logged to console.");
      return false;
    }

    const htmlContent = getCreativeEmailHtml(otp, purpose, email);
    const textFallback = [
      "========================================",
      "          V2NEXUS SECURE VPN            ",
      "========================================",
      "",
      isVerification ? "VERIFY YOUR EMAIL ADDRESS" : "PASSWORD RESET CODE",
      "",
      `Your 6-Digit Verification Code is: ${otp}`,
      "",
      "This code is valid for 5 minutes only.",
      "Never share this code with anyone.",
      "",
      `Issued for: ${email}`,
      "Sender: v2nexus.team@gmail.com",
      "========================================",
    ].join("\n");

    await transporter.sendMail({
      from: `"V2Nexus Team" <${smtpUser}>`,
      to: email,
      subject: isVerification
        ? `[V2Nexus] Verification Code: ${otp}`
        : `[V2Nexus] Password Reset Code: ${otp}`,
      text: textFallback,
      html: htmlContent,
    });

    console.log(`[AUTH OTP] Creative HTML email delivered successfully to ${email}`);
    return true;
  } catch (err: any) {
    console.warn(`[AUTH OTP] SMTP notice: ${err?.message || err}. (Code is available in backend console)`);
    return false;
  }
}
