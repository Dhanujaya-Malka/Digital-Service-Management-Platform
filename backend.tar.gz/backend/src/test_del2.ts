import { xuiService } from './xui';

async function del() {
  await xuiService.login();
  const res = await (xuiService as any).makeRequest(
    '/panel/api/clients/del/test_client_01@v2nexus.net',
    'POST',
    {
      Cookie: (xuiService as any).sessionCookie,
      'X-CSRF-Token': (xuiService as any).csrfToken,
      'X-Requested-With': 'XMLHttpRequest'
    }
  );
  console.log('del status:', res.statusCode, res.body);
}

del();
