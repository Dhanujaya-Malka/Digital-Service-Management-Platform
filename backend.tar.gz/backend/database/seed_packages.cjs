const { Pool } = require('pg');
const dotenv = require('dotenv');
const path = require('path');

dotenv.config({ path: path.join(__dirname, '../.env') });

const pool = new Pool({
  connectionString: process.env.DATABASE_URL || 'postgresql://postgres:cr2o7dinithi@localhost:5432/v2nexus_db',
  ssl: process.env.DATABASE_URL?.includes('localhost') ? false : { rejectUnauthorized: false },
});

const defaultPackages = [
  {
    id: 'basic-50gb',
    name: 'Basic 50 GB',
    price: 200,
    duration: 30,
    trafficLimit: 50,
    deviceLimit: 1,
    category: 'BASIC',
    features: [
      '50 GB High-Speed Data',
      '1 Device Connection',
      'Works on SLT, Dialog, Mobitel, Airtel & Hutch',
      'Ultra-Low Ping SG Route (35ms)',
      'NetMod & v2box App Ready',
    ],
    popular: false,
    availableSlots: 150,
    serverLocation: 'SG SERVER',
    validity: '1 Month',
    p2pTorrent: 'Restricted',
    speedLimit: 'No Speed Limit',
    badge: 'ACTIVE',
  },
  {
    id: 'basic-100gb',
    name: 'Basic 100 GB',
    price: 300,
    duration: 30,
    trafficLimit: 100,
    deviceLimit: 1,
    category: 'BASIC',
    features: [
      '100 GB High-Speed Data',
      '1 Device Connection',
      'Works on SLT, Dialog, Mobitel, Airtel & Hutch',
      'Direct V2Ray / Xray QR Code',
      '24/7 Dedicated Server Uptime',
    ],
    popular: false,
    availableSlots: 120,
    serverLocation: 'SG SERVER',
    validity: '1 Month',
    p2pTorrent: 'Restricted',
    speedLimit: 'No Speed Limit',
    badge: 'ACTIVE',
  },
  {
    id: 'basic-200gb',
    name: 'Basic 200 GB',
    price: 400,
    duration: 30,
    trafficLimit: 200,
    deviceLimit: 2,
    category: 'BASIC',
    features: [
      '200 GB High-Speed Data',
      '2 Devices Connection',
      'Full Speed Web & Social Streaming',
      'All Sri Lankan ISPs Supported',
      'Zero Speed Throttling',
    ],
    popular: false,
    availableSlots: 95,
    serverLocation: 'SG SERVER',
    validity: '1 Month',
    p2pTorrent: 'Restricted',
    speedLimit: 'No Speed Limit',
    badge: 'ACTIVE',
  },
  {
    id: 'standard-250gb',
    name: 'Standard 250 GB',
    price: 450,
    duration: 30,
    trafficLimit: 250,
    deviceLimit: 2,
    category: 'STANDARD',
    features: [
      '250 GB High-Speed Data',
      '2 Devices Connection',
      'Works with Video & Social Packs',
      'Low Latency Singapore Node',
      'Multi-protocol VLESS + Reality',
    ],
    popular: false,
    availableSlots: 90,
    serverLocation: 'SG SERVER',
    validity: '1 Month',
    p2pTorrent: 'Restricted',
    speedLimit: 'No Speed Limit',
    badge: 'ACTIVE',
  },
  {
    id: 'standard-300gb',
    name: 'Standard 300 GB',
    price: 500,
    duration: 30,
    trafficLimit: 300,
    deviceLimit: 3,
    category: 'STANDARD',
    features: [
      '300 GB High-Speed Data',
      '3 Devices Connection',
      'Full HD 1080p & 4K Streaming',
      'SLT, Dialog, Mobitel, Airtel, Hutch',
      'Instant Auto Setup via QR Code',
    ],
    popular: true,
    availableSlots: 85,
    serverLocation: 'SG SERVER',
    validity: '1 Month',
    p2pTorrent: 'Restricted',
    speedLimit: 'No Speed Limit',
    badge: 'POPULAR',
  },
  {
    id: 'standard-400gb',
    name: 'Standard 400 GB',
    price: 600,
    duration: 30,
    trafficLimit: 400,
    deviceLimit: 3,
    category: 'STANDARD',
    features: [
      '400 GB High-Speed Data',
      '3 Devices Connection',
      'High Bandwidth Gaming & Browsing',
      'Bypasses Zoom, Teams & Netflix',
      'Zero-Log Privacy Guaranteed',
    ],
    popular: false,
    availableSlots: 75,
    serverLocation: 'SG SERVER',
    validity: '1 Month',
    p2pTorrent: 'Restricted',
    speedLimit: 'No Speed Limit',
    badge: 'ACTIVE',
  },
  {
    id: 'premium-500gb',
    name: 'Premium 500 GB',
    price: 600,
    duration: 30,
    trafficLimit: 500,
    deviceLimit: 4,
    category: 'PREMIUM',
    features: [
      '500 GB Ultra-Fast Data',
      '4 Devices Connection',
      'Family & Multi-Device Sharing',
      'Torrent & P2P Allowed',
      'Singapore Premium High-Speed Node',
    ],
    popular: false,
    availableSlots: 65,
    serverLocation: 'SG SERVER',
    validity: '1 Month',
    p2pTorrent: 'Allowed',
    speedLimit: 'No Speed Limit',
    badge: 'HOT',
  },
  {
    id: 'premium-750gb',
    name: 'Premium 750 GB',
    price: 800,
    duration: 30,
    trafficLimit: 750,
    deviceLimit: 5,
    category: 'PREMIUM',
    features: [
      '750 GB Ultra-Fast Data',
      '5 Devices Connection',
      'High-Capacity Downloads & 4K',
      'All Sri Lankan Telecom Networks',
      'VIP Low Latency 35ms Route',
    ],
    popular: true,
    availableSlots: 50,
    serverLocation: 'SG SERVER',
    validity: '1 Month',
    p2pTorrent: 'Allowed',
    speedLimit: 'No Speed Limit',
    badge: 'POPULAR',
  },
  {
    id: 'premium-1000gb',
    name: 'Premium 1,000 GB (1 TB)',
    price: 1000,
    duration: 30,
    trafficLimit: 1000,
    deviceLimit: 6,
    category: 'PREMIUM',
    features: [
      '1,000 GB (1 TB) Data Quota',
      '6 Devices Connection',
      'Heavy Download & Server Workloads',
      'P2P / Torrent Supported',
      'Priority VIP Routing & Support',
    ],
    popular: false,
    availableSlots: 40,
    serverLocation: 'SG SERVER',
    validity: '1 Month',
    p2pTorrent: 'Allowed',
    speedLimit: 'No Speed Limit',
    badge: 'BEST VALUE',
  },
  {
    id: 'ultimate-1500gb',
    name: 'Ultimate 1,500 GB (1.5 TB)',
    price: 1200,
    duration: 30,
    trafficLimit: 1500,
    deviceLimit: 10,
    category: 'ULTIMATE',
    features: [
      '1,500 GB Huge Data Quota',
      'Unlimited Devices Connection',
      'Office & Shared Household Ready',
      'P2P & Torrent Full Speed',
      'Automated Failover & Dedicated Port',
    ],
    popular: false,
    availableSlots: 35,
    serverLocation: 'SG SERVER',
    validity: '1 Month',
    p2pTorrent: 'Allowed',
    speedLimit: 'No Speed Limit',
    badge: 'ACTIVE',
  },
  {
    id: 'ultimate-2000gb',
    name: 'Ultimate 2,000 GB (2 TB)',
    price: 1500,
    duration: 30,
    trafficLimit: 2000,
    deviceLimit: 10,
    category: 'ULTIMATE',
    features: [
      '2,000 GB (2 TB) Massive Data Quota',
      'Unlimited Devices Connection',
      'Extreme Power User & Enterprise Tier',
      'P2P / Torrent Fully Unlocked',
      'Maximum Singapore Bandwidth Pipe',
    ],
    popular: true,
    availableSlots: 25,
    serverLocation: 'SG SERVER',
    validity: '1 Month',
    p2pTorrent: 'Allowed',
    speedLimit: 'No Speed Limit',
    badge: 'ULTIMATE',
  },
];

async function seed() {
  console.log('Starting packages seed...');
  for (const p of defaultPackages) {
    const existing = await pool.query('SELECT id FROM packages WHERE slug = $1', [p.id]);
    if (existing.rows.length === 0) {
      await pool.query(
        `INSERT INTO packages (
          slug, name, category, price_lkr, duration_days, traffic_limit_gb, device_limit,
          features, popular, available_slots, server_location, validity, p2p_torrent, speed_limit, badge, is_active
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, true)`,
        [
          p.id,
          p.name,
          p.category,
          p.price,
          p.duration,
          p.trafficLimit,
          p.deviceLimit,
          JSON.stringify(p.features),
          p.popular,
          p.availableSlots,
          p.serverLocation,
          p.validity,
          p.p2pTorrent,
          p.speedLimit,
          p.badge,
        ]
      );
      console.log(`Inserted package: ${p.name}`);
    } else {
      console.log(`Package already exists: ${p.name}`);
    }
  }

  // Also remove or update the initial mock test row if needed
  await pool.query("DELETE FROM packages WHERE name = 'Test VPN Package'");

  const count = await pool.query('SELECT COUNT(*) FROM packages');
  console.log(`Total packages in database now: ${count.rows[0].count}`);
  await pool.end();
}

seed().catch((err) => {
  console.error('Seed failed:', err);
  process.exit(1);
});
