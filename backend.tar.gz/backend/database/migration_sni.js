const { Pool } = require('pg');
const dotenv = require('dotenv');
const path = require('path');

dotenv.config({ path: path.join(__dirname, '../.env') });

const pool = new Pool({
  connectionString: process.env.DATABASE_URL || 'postgresql://postgres:cr2o7dinithi@localhost:5432/v2nexus_db',
  ssl: process.env.DATABASE_URL?.includes('localhost') ? false : { rejectUnauthorized: false },
});

async function runMigration() {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    // 1. Add sni column to packages table
    await client.query('ALTER TABLE packages ADD COLUMN IF NOT EXISTS sni VARCHAR(255) DEFAULT \'aka.ms\';');
    console.log('✔ packages table updated with sni column');

    // 2. Create network_packages table if not exists
    await client.query(`
      CREATE TABLE IF NOT EXISTS network_packages (
        id VARCHAR(100) PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        isp VARCHAR(50) NOT NULL,
        isp_name VARCHAR(100) NOT NULL,
        status VARCHAR(50) DEFAULT 'active',
        server_location VARCHAR(100) DEFAULT 'SG SERVER',
        validity VARCHAR(50) DEFAULT '1 Month',
        p2p_torrent VARCHAR(50) DEFAULT 'Restricted',
        speed_limit VARCHAR(100) DEFAULT 'No Speed Limit',
        popular BOOLEAN DEFAULT false,
        features JSONB DEFAULT '[]'::jsonb,
        supported_protocols JSONB DEFAULT '["VLESS + Reality", "WebSocket TLS"]'::jsonb,
        latency VARCHAR(50) DEFAULT '30ms - 40ms',
        description TEXT,
        sni VARCHAR(255) DEFAULT 'aka.ms',
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      );
    `);
    console.log('✔ network_packages table created successfully');

    // 3. Seed initial network packages if table is empty
    const countRes = await client.query('SELECT count(*) FROM network_packages');
    if (parseInt(countRes.rows[0].count, 10) === 0) {
      const defaultPacks = [
        {
          id: 'dialog-router-zoom',
          name: 'Dialog (Wifi Router) ZOOM Unlimited',
          isp: 'dialog',
          isp_name: 'Dialog',
          sni: 'aka.ms',
          features: ['Dialog Home Broadband Router', 'No Speed Limit', 'Works with Work & Learn / Zoom', 'Unlimited Device Login'],
          desc: 'Optimized SNI tunneling for Dialog Home Broadband 4G WiFi Routers using aka.ms bypass.'
        },
        {
          id: 'dialog-sim-zoom-724',
          name: 'Dialog (Sim) ZOOM 724 Unlimited',
          isp: 'dialog',
          isp_name: 'Dialog',
          sni: 'www.zoom.com',
          features: ['Dialog Mobile SIM 4G', '724 Unlimited Plan', 'Speed Limited by Carrier', 'Unlimited Device Login'],
          desc: 'Specifically engineered for Dialog Mobile SIMs using www.zoom.com bypass.'
        },
        {
          id: 'dialog-social',
          name: 'Dialog Mobile Social Media',
          isp: 'dialog',
          isp_name: 'Dialog',
          sni: 'm.facebook.com',
          features: ['Dialog Social Media Pack', 'Facebook / WhatsApp / YouTube', 'No Speed Limit', 'Unlimited Device Login'],
          desc: 'Disguises total internet traffic under Dialog Social Media and Video unlimited plans.'
        },
        {
          id: 'slt-zoom',
          name: 'SLT ZOOM (Fibre, 4G, ADSL)',
          isp: 'slt',
          isp_name: 'SLT',
          sni: 'www.zoom.com',
          features: ['No Speed Limit', 'Works with Meet Lite/Max', 'Works with Flash 5/10', 'Unlimited Device Login'],
          desc: 'Bypass for SLT Zoom, Teams and Meeting learning bundles across Fibre, 4G & ADSL.'
        },
        {
          id: 'slt-netflix',
          name: 'SLT NETFLIX (Fibre, 4G, ADSL)',
          isp: 'slt',
          isp_name: 'SLT',
          sni: 'www.netflix.com',
          features: ['Works with 1990 Netflix package', 'No Speed Limit', 'SLT Fiber / 4G', 'Unlimited Device Login'],
          desc: 'Ultra-fast Netflix streaming SNI tunnel with high bandwidth throughput on SLT network.'
        },
        {
          id: 'slt-prepaid-235',
          name: 'SLT ZOOM PREPAID 235',
          isp: 'slt',
          isp_name: 'SLT',
          sni: 'www.zoom.com',
          features: ['No Speed Limit', 'SLT 4G Prepaid only', '235 package', 'Unlimited Device Login'],
          desc: 'Optimized specifically for SLT 4G prepaid SIMs with www.zoom.com SNI bypass.'
        },
        {
          id: 'hutch-social',
          name: 'Hutch Social Media',
          isp: 'hutch',
          isp_name: 'Hutch',
          sni: 'm.facebook.com',
          features: ['Works with Hutch Social & Gaming', 'Ultra Low Ping Singapore Gateway', 'Zero Speed Drops'],
          desc: 'Bypass for Hutch Social Media & Gaming packs.'
        },
        {
          id: 'mobitel-zoom',
          name: 'Mobitel ZOOM & Teams E-Learning',
          isp: 'mobitel',
          isp_name: 'Mobitel',
          sni: 'www.zoom.com',
          features: ['Mobitel 4G / 5G Ready', 'No Speed Throttling', 'Ultra-Low Latency Routing'],
          desc: 'Specialized for Mobitel Work & Learn package with www.zoom.com SNI.'
        },
        {
          id: 'airtel-social',
          name: 'Airtel Unlimited Social & Video',
          isp: 'airtel',
          isp_name: 'Airtel',
          sni: 'm.facebook.com',
          features: ['Airtel 4G Freedom Packs', 'High Speed Singapore Tunnel', 'Unlimited Downloads'],
          desc: 'Disguises traffic under Airtel Freedom unlimited social bundles.'
        }
      ];

      for (const p of defaultPacks) {
        await client.query(`
          INSERT INTO network_packages (
            id, name, isp, isp_name, sni, features, description, status, server_location, validity, p2p_torrent, speed_limit
          ) VALUES ($1, $2, $3, $4, $5, $6, $7, 'active', 'SG SERVER', '1 Month', 'Restricted', 'No Speed Limit')
          ON CONFLICT (id) DO UPDATE SET sni = EXCLUDED.sni;
        `, [
          p.id,
          p.name,
          p.isp,
          p.isp_name,
          p.sni,
          JSON.stringify(p.features),
          p.desc
        ]);
      }
      console.log(`✔ Seeded ${defaultPacks.length} network packages with custom SNIs`);
    } else {
      console.log('network_packages table already contains data, checking existing records');
    }

    await client.query('COMMIT');
    console.log('✔ Migration finished successfully!');
  } catch (err) {
    await client.query('ROLLBACK');
    console.error('Migration failed:', err);
  } finally {
    client.release();
    pool.end();
  }
}

runMigration();
