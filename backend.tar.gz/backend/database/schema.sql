-- ========================================================
-- V2Nexus Platform Database Schema
-- Production PostgreSQL DDL (Compatible with Neon, Supabase, Railway, VPS)
-- ========================================================

-- 1. Users Table
CREATE TABLE IF NOT EXISTS public.users (
  id BIGSERIAL PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  email VARCHAR(255) UNIQUE NOT NULL,
  phone VARCHAR(255),
  password_hash TEXT NOT NULL,
  role VARCHAR(50) DEFAULT 'CUSTOMER' NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL,
  email_verified BOOLEAN DEFAULT FALSE NOT NULL
);

-- 2. Packages Table
CREATE TABLE IF NOT EXISTS public.packages (
  id BIGSERIAL PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  category VARCHAR(100) NOT NULL,
  price_lkr NUMERIC NOT NULL,
  duration_days INTEGER NOT NULL,
  traffic_limit_gb NUMERIC NOT NULL,
  device_limit INTEGER NOT NULL,
  is_active BOOLEAN DEFAULT TRUE NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL,
  features JSONB DEFAULT '[]'::jsonb,
  popular BOOLEAN DEFAULT FALSE,
  available_slots INTEGER DEFAULT 100,
  server_location VARCHAR(255) DEFAULT 'SG SERVER',
  validity VARCHAR(255) DEFAULT '1 Month',
  p2p_torrent VARCHAR(255) DEFAULT 'Restricted',
  speed_limit VARCHAR(255) DEFAULT 'No Speed Limit',
  badge VARCHAR(100) DEFAULT 'ACTIVE',
  slug VARCHAR(255),
  sni VARCHAR(255) DEFAULT 'aka.ms'
);

-- 3. Network Packages Table (ISP specific bypass)
CREATE TABLE IF NOT EXISTS public.network_packages (
  id VARCHAR(255) PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  isp VARCHAR(100) NOT NULL,
  isp_name VARCHAR(100) NOT NULL,
  status VARCHAR(50) DEFAULT 'active',
  server_location VARCHAR(255) DEFAULT 'SG SERVER',
  validity VARCHAR(100) DEFAULT '1 Month',
  p2p_torrent VARCHAR(100) DEFAULT 'Restricted',
  speed_limit VARCHAR(100) DEFAULT 'No Speed Limit',
  popular BOOLEAN DEFAULT FALSE,
  features JSONB DEFAULT '[]'::jsonb,
  supported_protocols JSONB DEFAULT '["VLESS + Reality", "WebSocket TLS"]'::jsonb,
  latency VARCHAR(100) DEFAULT '30ms - 40ms',
  description TEXT,
  sni VARCHAR(255) DEFAULT 'aka.ms',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 4. Orders Table
CREATE TABLE IF NOT EXISTS public.orders (
  id BIGSERIAL PRIMARY KEY,
  user_id BIGINT NOT NULL,
  package_id BIGINT NOT NULL,
  amount_lkr NUMERIC NOT NULL,
  status VARCHAR(50) DEFAULT 'PENDING' NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL
);

-- 5. Payments Table
CREATE TABLE IF NOT EXISTS public.payments (
  id BIGSERIAL PRIMARY KEY,
  order_id BIGINT NOT NULL,
  amount_lkr NUMERIC NOT NULL,
  payment_method VARCHAR(50) DEFAULT 'BANK_TRANSFER' NOT NULL,
  transaction_reference VARCHAR(255),
  payment_proof_url TEXT,
  status VARCHAR(50) DEFAULT 'PENDING' NOT NULL,
  reviewed_by BIGINT,
  reviewed_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL
);

-- 6. Email OTP Verification Table
CREATE TABLE IF NOT EXISTS public.email_otps (
  id BIGSERIAL PRIMARY KEY,
  user_id BIGINT NOT NULL,
  purpose VARCHAR(50) NOT NULL,
  otp_hash TEXT NOT NULL,
  expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
  attempts INTEGER DEFAULT 0 NOT NULL,
  used_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL
);

-- 7. System Settings Table (Server Capacity, Quota Reset, etc.)
CREATE TABLE IF NOT EXISTS public.system_settings (
  key VARCHAR(255) PRIMARY KEY,
  value TEXT,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Recommended Indexes for High Performance
CREATE INDEX IF NOT EXISTS idx_users_email ON public.users(email);
CREATE INDEX IF NOT EXISTS idx_orders_user_id ON public.orders(user_id);
CREATE INDEX IF NOT EXISTS idx_orders_status ON public.orders(status);
CREATE INDEX IF NOT EXISTS idx_payments_order_id ON public.payments(order_id);
CREATE INDEX IF NOT EXISTS idx_email_otps_user_id ON public.email_otps(user_id);
CREATE INDEX IF NOT EXISTS idx_packages_active ON public.packages(is_active);
CREATE INDEX IF NOT EXISTS idx_network_packages_isp ON public.network_packages(isp);
